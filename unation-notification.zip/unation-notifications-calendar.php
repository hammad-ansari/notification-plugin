<link rel="stylesheet" href="<?php echo UNATION_NOTIFICATIONS_URL; ?>assets/css/toastr.css">
<link rel="stylesheet" href="<?php echo UNATION_NOTIFICATIONS_URL; ?>assets/css/tui-time-picker.min.css">
<link rel="stylesheet" href="<?php echo UNATION_NOTIFICATIONS_URL; ?>assets/css/tui-date-picker.min.css">
<link rel="stylesheet" href="<?php echo UNATION_NOTIFICATIONS_URL; ?>assets/css/toastui-calendar.css">
<link rel="stylesheet" href="<?php echo UNATION_NOTIFICATIONS_URL; ?>assets/css/app.css">
<link rel="stylesheet" href="<?php echo UNATION_NOTIFICATIONS_URL; ?>assets/css/icons.css">

<script src="<?php echo UNATION_NOTIFICATIONS_URL; ?>assets/js/toastr.min.js"></script>
<script src="<?php echo UNATION_NOTIFICATIONS_URL; ?>assets/js/moment.min.js"></script>
<script src="<?php echo UNATION_NOTIFICATIONS_URL; ?>assets/js/chance.min.js"></script>
<script src="<?php echo UNATION_NOTIFICATIONS_URL; ?>assets/js/tui-time-picker.min.js"></script>
<script src="<?php echo UNATION_NOTIFICATIONS_URL; ?>assets/js/tui-date-picker.min.js"></script>
<script src="<?php echo UNATION_NOTIFICATIONS_URL; ?>assets/js/toastui-calendar.ie11.min.js"></script>
<script src="<?php echo UNATION_NOTIFICATIONS_URL; ?>assets/js/utils.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>

<script src='https://qa.unation.com/wp-content/plugins/the-events-calendar/common/vendor/tribe-selectWoo/dist/js/selectWoo.full.min.js?ver=4.15.3' id='tribe-select2-js'></script>

<!-- jQuery Modal -->
<script src="<?php echo UNATION_NOTIFICATIONS_URL; ?>assets/js/jquery.modal.min.js"></script>
<script src="<?php echo UNATION_NOTIFICATIONS_URL; ?>assets/css/jquery.modal.min.css"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" integrity="sha512-nMNlpuaDPrqlEls3IX/Q56H36qvBASwb3ipuo3MxeWbsQB1881ox0cRv7UPTgBlriqoynt35KjEwgGUeUXIPnw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js" integrity="sha512-2ImtlRlf2VVmiGZsjm9bEyhjGW4dU7B6TNwh/hx/iSByxNENtj3WVE6o/9Lj4TJeVXPi4bnOIMXFIJJAeufa0A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<?php

include 'inc/helper.php';
include 'inc/styles.php';

?>
<style type="text/css">



</style>

<div class="app-container code-html">
    <article class="content">
        <section class="app-column">
            <nav class="navbar">

                <div class="left">
                    <button class="button is-is-square today">Today</button>
                    <button class="button is-is-square prev">
                        <img alt="prev" src="https://nhn.github.io/tui.calendar/latest/examples/images/ic-arrow-line-left.png" srcset="
                        https://nhn.github.io/tui.calendar/latest/examples/images/ic-arrow-line-left@2x.png 2x,
                        https://nhn.github.io/tui.calendar/latest/examples/images/ic-arrow-line-left@3x.png 3x
                        ">
                    </button>
                    <button class="button is-is-square next">
                        <img alt="prev" src="https://nhn.github.io/tui.calendar/latest/examples/images/ic-arrow-line-right.png" srcset="
                        https://nhn.github.io/tui.calendar/latest/examples/images/ic-arrow-line-right@2x.png 2x,
                        https://nhn.github.io/tui.calendar/latest/examples/images/ic-arrow-line-right@3x.png 3x
                        ">
                    </button>
                    <span class="navbar--range"></span>
                    <!-- <span class="navbar--timezone"><?php echo $calendar['timezone']; ?></span> -->
                </div>

                <div class="right">

                    <div class="dropdown">
                        <div class="dropdown-trigger">
                            <button class="button is-is-square" aria-haspopup="true" aria-controls="dropdown-menu">
                                <span class="button-text"></span>
                                <span class="dropdown-icon toastui-calendar-icon toastui-calendar-ic-dropdown-arrow"></span>
                            </button>
                        </div>
                        <div class="dropdown-menu">
                            <div class="dropdown-content">
                                <a href="#" class="dropdown-item" data-view-name="month">Monthly</a>
                                <a href="#" class="dropdown-item" data-view-name="week">Weekly</a>
                                <a href="#" class="dropdown-item" data-view-name="day">Daily</a>
                            </div>
                        </div>
                    </div>

                    <div class="round-button">
                        <span class="plus-sign">+</span>
                    </div>

                </div>

            </nav>
            <main id="app"></main>
        </section>
    </article>
</div>

<!-- Add Event Popup -->
<div class="event-popup add-event-popup">
    <div class="event-popup-inn">
        <div class="event-popup-heading mb-10">
            <h3>Add Notification</h3>
            <span class="event-popup-close-link"><img src="https://s38939.pcdn.co/wp-content/themes/hello-theme-child-master/aws/img/get-tickets-close.svg" alt=""></span>
        </div>
        <div class="event-form">
            <form id="add-event">

                <!-- <div class="form-row">
                    <div class="column-2">
                        <input type="text" name="title" placeholder="Subject *" required style="width:100%;">
                    </div>
                </div> -->

                <div class="unef-field-item-wrap flex">
                    <div class="unef-field-item full">
                        <label class="unef-field-label" for="title">Title<span class="req">*</span></label>
                        <div class="unef-field-container">
                            <input type="text" name="title" value="" id="title" class="inputField" minlength="3" maxlength="32" required="">
                        </div>
                        <div class="character-limit"><span>0</span>/32</div>
                        <div class="error-msg" style="display: none;">Must be between 3 and 32 characters.</div>
                    </div>
                </div>

                <!-- <div class="form-row">
                    <label for="schedule-notification">Schedule Date (EST)</label>
                    <div class="column-3">
                        <input type="datetime-local" id="schedule-start-date" name="schedule_start_date" placeholder="Start date" required>
                    </div>
                </div> -->

                <div class="unef-field-item-wrap flex">
                    <div class="unef-field-item" style="padding-right: 10px">
                        <label class="unef-field-label" for="schedule-date">Date <span class="req">*</span></label>
                        <div class="unef-field-container">
                            <input type="text" name="schedule_date" value="" class="schedule-date" id="schedule-date" />
                        </div>
                    </div>
                    <div class="unef-field-item">
                        <label class="unef-field-label" for="schedule-time">Time <span class="req">*</span></label>
                        <div class="unef-field-container">
                            <input type="text" name="schedule_time" value="" class="schedule-time" id="schedule-time" />
                            <input type="hidden" name="text_message_action" value="schedule">
                        </div>
                    </div>
                </div>


                <div class="form-row mb-10">
                    <label style="vertical-align: top;font-weight: 600">Send Notification to</label>

                    <label class="radio-container">
                        <input type="radio" name="notification-type" value="all" required>All
                    </label>

                    <label class="radio-container">
                        <input type="radio" name="notification-type" value="metro">Metro
                    </label>

                    <label class="radio-container">
                        <input type="radio" name="notification-type" value="users">Users
                    </label>
                </div>

                <div class="all-selected unef-field-item-wrap flex hide-field">
                    <div class="flex-item-1">
                    <div class="d-flex un-content-type-field">
                        <img src="https://qa.unation.com/wp-content/plugins/unation-marketing-emails/img/Fill 3.svg" style="margin-right: 13px;position: absolute;z-index: 9999999;padding-top: 9px;margin-top: 2px;padding-left: 13px;">
                        <select name="un-search-content" class="mySelect un-content-id" multiple="multiple"></select>

                    </div>


                    <div class="unef-field-item full un-product-url-field hide-field">
                        <label class="unef-field-label" for="title">URL<span class="req">*</span></label>
                        <div class="unef-field-container">
                            <input type="text" name="element-9" value="" id="title" class="inputField" minlength="3" maxlength="60" required="">
                        </div>
                    </div>
                   

                    </div>
                    <div class="flex-item-2">
                         <select name="notification-content-type" id="notification-content-type" class="un-content-type add-un-content-type" required>
                            <option value="events">Event</option>
                            <option value="guides">Guide</option>
                            <option value="deals">Offer</option>
                            <option value="product">Product</option>
                            <option value="company">Company</option>
                        </select>
                    </div>
                    <div class="selectedOptions"></div>
                </div>

                <div class="metro-selected unef-field-item-wrap flex hide-field">

                    <div class="metro-item unef-field-item" style="padding-right: 10px">

                        <label class="unef-field-label" for="title">URL<span class="req">*</span></label>
                        <div class="unef-field-container">
                            <select name="notification-metro" class="un-metro add-un-metro">
                                <option value="" selected>All Metros</option>
                                <option value="Atlanta">Atlanta</option>
                                <option value="Austin">Austin</option>
                                <option value="Charlotte">Charlotte</option>
                                <option value="Dallas">Dallas</option>
                                <option value="Houston">Houston</option>
                                <option value="Jacksonville">Jacksonville</option>
                                <option value="Memphis">Memphis</option>
                                <option value="Miami">Miami</option>
                                <option value="Nashville">Nashville</option>
                                <option value="Orlando">Orlando</option>
                                <option value="Philadelphia">Philadelphia</option>
                                <option value="Pittsburgh">Pittsburgh</option>
                                <option value="Raleigh">Raleigh</option>
                                <option value="San Antonio">San Antonio</option>
                                <option value="Tampa Bay">Tampa Bay</option>
                            </select>
                        </div>
                    </div>
                    <div class="content-type-item flex">
                        
                        <div class="flex-item-1">
                            <div class="d-flex un-content-type-field">
                                <img src="https://qa.unation.com/wp-content/plugins/unation-marketing-emails/img/Fill 3.svg" style="margin-right: 13px;position: absolute;z-index: 9999999;padding-top: 9px;margin-top: 2px;padding-left: 13px;">
                                <?php
                                global $unawsAlgoliaQueryObj;
                                $algoliaIndex = $unawsAlgoliaQueryObj;

                                $result = $algoliaIndex->search('', array(
                                    "facetFilters" => array(
                                        "type:events"
                                    )
                                ));
                                $hits = $result["hits"];

                                $event_results = array();
                                foreach ($hits as $hit) {
                                    array_push($event_results, array(
                                        "id" => $hit["id"],
                                        "text" => $hit["name"]
                                    ));
                                }
                                ?>
                                <select name="" class="mySelect" multiple="multiple">
                                    <?php 
                                    foreach ($event_results as $key => $value) {
                                        ?>
                                        <option value="<?=$value['id']?>"><?= $value['text'] ?></option>
                                        <?php
                                    }
                                    ?>
                                </select>
                            </div>

                            <div class="unef-field-item full un-product-url-field hide-field">
                                <label class="unef-field-label" for="title">URL<span class="req">*</span></label>
                                <div class="unef-field-container">
                                    <input type="text" name="element-9" value="" id="title" class="inputField" minlength="3" maxlength="60" required="">
                                </div>
                            </div>
                    
                        </div>
                        <div class="flex-item-2">
                             <select name="notification-content-type" id="notification-content-type" class="un-content-type add-un-content-type" required>
                                <option value="events">Event</option>
                                <option value="guides">Guide</option>
                                <option value="deals">Offer</option>
                                <option value="product">Product</option>
                                <option value="company">Company</option>
                            </select>
                        </div>
                        <div class="selectedOptions"></div>

                    </div>
                </div>

                <div class="users-selected unef-field-item-wrap flex hide-field ">

                    <div class="users-item unef-field-item" style="padding-right: 10px;">

                        <label class="unef-field-label" for="title">Users<span class="req">*</span></label>
                        <div class="unef-field-container">
                            <div class="d-flex un-content-type-field">
                                <img src="https://qa.unation.com/wp-content/plugins/unation-marketing-emails/img/Fill 3.svg" style="margin-right: 13px;position: absolute;z-index: 9999999;padding-top: 9px;margin-top: 7px;padding-left: 13px;margin-left: 5px;height: 30px;width: 30px;">
                                <select name="un-search-users" class="mySelect" multiple="multiple">
                                    <option>user 1</option>
                                    <option>user 2</option>
                                    <option>user 3</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="content-type-item flex">
                        
                        <div class="flex-item-1">
                            <div class="d-flex un-content-type-field">
                                <img src="https://qa.unation.com/wp-content/plugins/unation-marketing-emails/img/Fill 3.svg" style="margin-right: 13px;position: absolute;z-index: 9999999;padding-top: 9px;margin-top: 2px;padding-left: 13px;">
                                <?php
                                global $unawsAlgoliaQueryObj;
                                $algoliaIndex = $unawsAlgoliaQueryObj;

                                $result = $algoliaIndex->search('', array(
                                    "facetFilters" => array(
                                        "type:events"
                                    )
                                ));
                                $hits = $result["hits"];

                                $event_results = array();
                                foreach ($hits as $hit) {
                                    array_push($event_results, array(
                                        "id" => $hit["id"],
                                        "text" => $hit["name"]
                                    ));
                                }
                                ?>
                                <select name="" class="mySelect" multiple="multiple">
                                    <?php 
                                    foreach ($event_results as $key => $value) {
                                        ?>
                                        <option value="<?=$value['id']?>"><?= $value['text'] ?></option>
                                        <?php
                                    }
                                    ?>
                                </select>
                            </div>

                            <div class="unef-field-item full un-product-url-field hide-field">
                                <label class="unef-field-label" for="title">URL<span class="req">*</span></label>
                                <div class="unef-field-container">
                                    <input type="text" name="element-9" value="" id="title" class="inputField" minlength="3" maxlength="60" required="">
                                </div>
                            </div>
                    
                        </div>
                        <div class="flex-item-2">
                             <select name="notification-content-type" id="notification-content-type" class="un-content-type add-un-content-type" required>
                                <option value="events">Event</option>
                                <option value="guides">Guide</option>
                                <option value="deals">Offer</option>
                                <option value="product">Product</option>
                                <option value="company">Company</option>
                            </select>
                        </div>
                        <div class="selectedOptions"></div>
                    </div>

                    <div class="viewselectedUsers"></div>
                    
                </div>
                
                <!-- <div class="form-row users-field hide-field">
                    <select name="notification-users" id="notification-users" class="un-users" style="width:100%!important;"></select>
                </div> -->

                <!-- <div class="form-row metro-field hide-field">
                    <select name="notification-metro" class="un-metro">
                        <option value="" selected>All Metros</option>
                        <option value="Atlanta">Atlanta</option>
                        <option value="Austin">Austin</option>
                        <option value="Charlotte">Charlotte</option>
                        <option value="Dallas">Dallas</option>
                        <option value="Houston">Houston</option>
                        <option value="Jacksonville">Jacksonville</option>
                        <option value="Memphis">Memphis</option>
                        <option value="Miami">Miami</option>
                        <option value="Nashville">Nashville</option>
                        <option value="Orlando">Orlando</option>
                        <option value="Philadelphia">Philadelphia</option>
                        <option value="Pittsburgh">Pittsburgh</option>
                        <option value="Raleigh">Raleigh</option>
                        <option value="San Antonio">San Antonio</option>
                        <option value="Tampa Bay">Tampa Bay</option>
                    </select>
                </div> -->

                <!-- <div class="form-row content-field hide-field">
                    <div class="column-2">
                        <select name="notification-content-type" id="notification-content-type" class="un-content-type" required>
                            <option value="" selected>Select Content Type</option>
                            <option value="events">Event</option>
                            <option value="guides">Guide</option>
                            <option value="deals">Offer</option>
                            <option value="product">Product</option>
                            <option value="company">Company</option>
                        </select>
                        <select name="notification-content-id" id="notification-content-id" class="un-content-id" style="width: 70%;" required>
                            <option>Type to Search</option>
                        </select>

                        <input type="text" name="notification-url" id="notification-url-id" placeholder="Enter URL" value="" style="width: 100%;">

                    </div>
                </div> -->

                <!-- <div class="form-row">
                    <label for="event-notification">Notification Text *</label>
                    <textarea id="event-notification" name="event-notification" rows="5" required></textarea>
                </div> -->

                <div class="unef-field-item-wrap flex">
                    <div class="unef-field-item full">
                        <label class="unef-field-label" for="title">Description<span class="req">*</span></label>
                        <div class="unef-field-container">
                            <input type="text" name="event-notification" value="" id="event-notification" class="inputField" minlength="3" maxlength="116" required="">
                        </div>
                        <div class="character-limit"><span>0</span>/116</div>
                        <div class="error-msg" style="display: none;">Must be between 3 and 116 characters.</div>
                    </div>
                </div>

                <!-- <div class="form-row">
                    <label for="event-notification">Highlighted Text</label>
                    <textarea id="event-highlighted-text" name="event-highlighted-text" rows="1" disabled style="color: #2c3338;"></textarea>
                </div> -->

                <div class="unef-field-item-wrap flex mb-10">
                    <div class="unef-field-item full">
                        <label class="unef-field-label" for="title">Highlighted Text<span class="req">*</span></label>
                        <div class="unef-field-container">
                            <input type="text" name="event-highlighted-text" value="" id="event-highlighted-text" class="inputField" minlength="3" maxlength="32" disabled>
                        </div>
                        <div class="character-limit"><span>0</span>/32</div>
                        <div class="error-msg" style="display: none;">Must be between 3 and 32 characters.</div>
                    </div>
                </div>

                <div class="form-row mt-45">

                    <button type="submit" class="toastui-calendar-popup-button toastui-calendar-popup-confirm save-event">
                        <span>
                            <div class="toastui-calendar-template-popupSave">Schedule</div>
                        </span>
                    </button>

                    <button class="toastui-calendar-popup-button toastui-calendar-popup-confirm send-notification-now" style="margin-right: 20px;">
                        <span>
                            <div class="toastui-calendar-template-popupSave">Send Now</div>
                        </span>
                    </button>

                </div>

            </form>

        </div>
    </div>
</div>
<!-- Add Event Popup End -->

<!-- Edit Event Popup -->
<div class="event-popup edit-event-popup">
    <div class="event-popup-inn">
        <div class="event-popup-heading">
            <h3>Edit Notification</h3>
            <span class="event-popup-close-link"><img src="https://s38939.pcdn.co/wp-content/themes/hello-theme-child-master/aws/img/get-tickets-close.svg" alt=""></span>
        </div>
        <div class="event-form">
            <form id="edit-event">
                <input type="hidden" name="edit_event_id" id="edit_event_id" value="">
                <input type="hidden" name="delete_event_id" id="delete_event_id" value="">
                <input type="hidden" name="delete_calendar_id" id="delete_calendar_id" value="">

                <div class="form-row">
                    <div class="column-2">
                        <input type="text" name="title" placeholder="Subject *" required style="width:80%;">
                        <div></div>
                    </div>
                </div>

                <div class="form-row">
                    <label for="schedule-notification">Schedule Date (EST)</label>
                    <div class="column-3">
                        <input type="datetime-local" id="schedule-start-date" name="schedule_start_date" placeholder="Start date" required>
                    </div>
                </div>

                <div class="form-row">
                    <label style="vertical-align: top;">
                        Send Notification to
                    </label>

                    <label class="radio-container">All
                        <input type="radio" name="notification-type" value="all" required>
                        <span class="checkmark"></span>
                    </label>

                    <label class="radio-container">Metro
                        <input type="radio" name="notification-type" value="metro">
                        <span class="checkmark"></span>
                    </label>

                    <label class="radio-container">Users
                        <input type="radio" name="notification-type" value="users">
                        <span class="checkmark"></span>
                    </label>
                </div>

                <div class="form-row users-field hide-field">
                    <select name="notification-users" id="notification-users" class="un-users" style="width:100%!important;"></select>
                </div>

                <div class="form-row metro-field hide-field">
                    <select name="notification-metro" class="un-metro">
                        <option value="" selected>Select Metro (Optional)</option>
                        <option value="Atlanta">Atlanta</option>
                        <option value="Austin">Austin</option>
                        <option value="Charlotte">Charlotte</option>
                        <option value="Dallas">Dallas</option>
                        <option value="Houston">Houston</option>
                        <option value="Jacksonville">Jacksonville</option>
                        <option value="Memphis">Memphis</option>
                        <option value="Miami">Miami</option>
                        <option value="Nashville">Nashville</option>
                        <option value="Orlando">Orlando</option>
                        <option value="Philadelphia">Philadelphia</option>
                        <option value="Pittsburgh">Pittsburgh</option>
                        <option value="Raleigh">Raleigh</option>
                        <option value="San Antonio">San Antonio</option>
                        <option value="Tampa Bay">Tampa Bay</option>
                    </select>
                </div>

                <div class="form-row content-field hide-field">
                    <div class="column-2">
                        <select name="notification-content-type" id="notification-content-type" class="un-content-type" required>
                            <option value="" selected>Select Content Type</option>
                            <option value="events">Event</option>
                            <option value="guides">Guide</option>
                            <option value="deals">Offer</option>
                            <option value="product">Product</option>
                            <option value="company">Company</option>
                        </select>
                        <select name="notification-content-id" id="notification-content-id" class="un-content-id" style="width: 70%;" required>
                            <option>Type to Search</option>
                        </select>

                        <input type="text" name="notification-url" id="notification-url-id" placeholder="Enter URL" value="" style="width: 100%;">

                    </div>
                </div>

                <div class="form-row">
                    <label for="event-notification">Notification Text *</label>
                    <textarea id="event-notification" name="event-notification" rows="5" required></textarea>
                </div>

                <div class="form-row">
                    <label for="event-notification">Highlighted Text</label>
                    <textarea id="event-highlighted-text" name="event-highlighted-text" rows="1" disabled style="color: #2c3338;"></textarea>
                </div>

                <div class="form-row">
                    <button type="submit" class="toastui-calendar-popup-button toastui-calendar-popup-confirm update-event">
                        <span>
                            <div class="toastui-calendar-template-popupSave">Update</div>
                        </span>
                    </button>
                </div>

                <div class="form-row">
                    <button type="button" class="toastui-calendar-popup-button toastui-calendar-popup-confirm delete-event" style="margin-right: 20px;">
                        <span>
                            <div class="toastui-calendar-template-popupSave">Delete</div>
                        </span>
                    </button>
                </div>

            </form>

        </div>
    </div>
</div>
<!-- Edit Event Popup End -->


<script>
    // Document ready function
    jQuery(document).ready(function($) {
      // jQuery event handler for textareas with name "event-notification"
      $('textarea[name="event-notification"]').on('mouseup', function() {
        const textarea = $(this);
        const selectedText = textarea.val().substring(textarea[0].selectionStart, textarea[0].selectionEnd);

        // Update the second textarea with the selected text
        const highlightedTextarea = $('textarea[name="event-highlighted-text"]');
        highlightedTextarea.val(selectedText);

        // Scroll to the end of the second textarea to keep the cursor visible
        highlightedTextarea.scrollTop(highlightedTextarea[0].scrollHeight);
    });
  });
</script>

<?php


$args = array(
    'post_type' => 'notification', // Custom post type 'notification'
    'post_status' => 'publish',    // Fetch published posts
    'posts_per_page' => -1         // Get all published posts (-1 means no limit)
);

// The Query
$the_query = new WP_Query($args);

$events_data = array();

if ($the_query->have_posts()) {
    while ($the_query->have_posts()) {
        $the_query->the_post();

        $event_id = get_the_ID();
        $event_schedule_date = get_post_meta($event_id, 'schedule_datetime', true);
        $events_data[] = array('event_title' => get_the_title(), 'schedule_date' => $event_schedule_date);
    }
    /* Restore original Post Data */
    wp_reset_postdata();
}

$jsonEvents = json_encode($events_data);
?>
<script>
    var eventsFromPHP = <?php echo $jsonEvents; ?>;

    var formattedEvents = jQuery.map(eventsFromPHP, function(event, index) {
        return {
            id: 'event' + (index + 1),
            calendarId: '1',
            title: event.event_title,
            start: event.schedule_date,
            end: event.schedule_date // You might want to add an end date or calculate it based on some logic.
        };
    });

    console.log('FORMATED EVENTS', formattedEvents);
</script>

<?php
// echo '<pre>';
// print_r($events_data);
// echo '</pre>';

?>

<script>
    jQuery(document).ready(function($) {

        if (jQuery(".schedule-time").length > 0) {
            var schDate = jQuery(".schedule-date").datepicker({
                disabled: false,
                firstDay: 0,
                minDate: 0,
                altField: "#us-date-out",
                altFormat: "D, M dd, yy",
                dateFormat: "D, M dd, yy",
                onSelect: function(date) {
                    var selectedSchDate = new Date(date);
                },
            });
            schDate.datepicker("setDate", new Date());

            // Get the current date and time
            const currentTime = new Date();

            // Increment the hour by 1
            currentTime.setHours(currentTime.getHours() + 1);

            // Get the hours and minutes in the format "HH:mm"
            const nextHour = ("0" + currentTime.getHours()).slice(-2) + ":00";

            // Set up the timepicker with the next hour as the default time
            jQuery(".schedule-time").timepicker({
                defaultTime: nextHour,
                startTime: "19:00",
            });
            var selSchDate = jQuery("#schedule-date").val();
            var selSchTime = jQuery("#schedule-time").val();
        }

        $('.add-event-popup input[name="notification-type"]').on('change', function() {
            let notification_type = $(this).val();

            if (notification_type == "all") {

                $(".metro-selected").addClass("hide-field");
                $(".users-selected").addClass("hide-field");
                // $(".metro-field select").val("");

                // var usersField = $('.users-field');
                // usersField.addClass("hide-field");
                // $('.un-users').val([]).trigger('change');

                $(".all-selected").removeClass("hide-field");

            } else if (notification_type == "metro") {

                // var usersField = $('.users-field');
                // usersField.addClass("hide-field");
                // $('.un-users').val([]).trigger('change');

                $(".all-selected").addClass("hide-field");
                $(".users-selected").addClass("hide-field");
                $(".metro-selected").removeClass("hide-field");

            } else if (notification_type == "users") {

                $(".all-selected").addClass("hide-field");
                $(".metro-selected").addClass("hide-field");

                $(".users-selected").removeClass("hide-field");
                // $(".content-field").removeClass("hide-field");

            }
        });

        $('.add-event-popup select.add-un-content-type').on('change', function() {

            let content_type = $(this).val();

            if (content_type == "product") {

                $(".un-product-url-field").removeClass('hide-field');
                $(".un-content-type-field").addClass('hide-field');
            }else{
                $(".un-content-type-field").removeClass('hide-field');
                $(".un-product-url-field").addClass('hide-field');
            }

        })

        $('.add-event-popup .un-users').select2({
            placeholder: 'Type to Search Users',
            minimumInputLength: 1,
            multiple: true,
            language: {
                searching: function() {
                    return "Searching…";
                },
            },
            ajax: {
                url: my_ajaxurl.ajax_url, // Replace with the actual path to your PHP script
                dataType: 'json',
                delay: 1000,
                data: function(params) {
                    return {
                        action: 'un_notification_get_users_data_from_algolia',
                        search: params.term
                    };
                },
                processResults: function(data) {
                    return {
                        results: $.map(data, function(item) {
                            return {
                                id: item[0],
                                text: item[1]
                            };
                        })
                    };
                },
                cache: true
            }
        });


        $('.edit-event-popup input[name="notification-type"]').on('change', function() {
            let notification_type = $(this).val();

            if (notification_type == "all") {

                $(".metro-field").addClass("hide-field");
                $(".metro-field select").val("");

                var usersField = $('.users-field');
                usersField.addClass("hide-field");
                $('.un-users').val([]).trigger('change');

                $(".content-field").removeClass("hide-field");

            } else if (notification_type == "metro") {

                var usersField = $('.users-field');
                usersField.addClass("hide-field");
                $('.un-users').val([]).trigger('change');

                $(".metro-field").removeClass("hide-field");
                $(".content-field").removeClass("hide-field");

            } else if (notification_type == "users") {

                $(".metro-field").addClass("hide-field");
                $(".metro-field select").val("");

                $(".users-field").removeClass("hide-field");
                $(".content-field").removeClass("hide-field");

            }
        });

        $('.edit-event-popup .un-users').select2({
            placeholder: 'Type to Search Users',
            minimumInputLength: 1,
            multiple: true,
            language: {
                searching: function() {
                    return "Searching…";
                },
            },
            ajax: {
                url: my_ajaxurl.ajax_url, // Replace with the actual path to your PHP script
                dataType: 'json',
                delay: 1000,
                data: function(params) {
                    return {
                        action: 'un_notification_get_users_data_from_algolia',
                        search: params.term
                    };
                },
                processResults: function(data) {
                    return {
                        results: $.map(data, function(item) {
                            return {
                                id: item[0],
                                text: item[1]
                            };
                        })
                    };
                },
                cache: true
            }
        });


        $('#notification-url-id').hide(); // Hide text field initially

        $('#notification-content-type').change(function() {
            var selectedValue = $(this).val();

            if (selectedValue === 'product' || selectedValue === 'company') {
                $('#notification-url-id').show();
                $('#notification-content-id').next('.select2-container').hide();
            } else {
                $('#notification-url-id').hide();
                $('#notification-content-id').next('.select2-container').show();
            }
        });


        var contentType = $('#edit-event #notification-content-type').val();
        if (contentType === 'product' || contentType === 'company') {
            $('#edit-event #notification-url-id').show();
            $('#notification-content-id').next('.select2-container').hide();
        } else {
            $('#edit-event #notification-url-id').hide();
            $('#notification-content-id').next('.select2-container').show();
        }
        // $('#edit-event #notification-url-id').hide(); // Hide text field initially

        $('#edit-event #notification-content-type').change(function() {
            var selectedValue = $(this).val();

            if (selectedValue === 'product' || selectedValue === 'company') {
                $('#edit-event #notification-url-id').show();
                $('.select2').hide();
            } else {
                $('#edit-event #notification-url-id').hide();
                $('.select2').show();
            }
        });

        var CONTENT_CALENDAR_COLOR = "#E7F8FF";
        var CONTENT_CALENDAR_TEXT_COLOR = "#039BDC";

        function initializeContentSelect2($element, contentSelector, metroSelector) {
            $element.select2({
                placeholder: 'Type to Search',
                minimumInputLength: 1,
                language: {
                    searching: function() {
                        return "Searching…";
                    },
                },
                ajax: {
                    url: my_ajaxurl.ajax_url, // Replace with the actual path to your PHP script
                    dataType: 'json',
                    delay: 1000,
                    data: function(params) {
                        return {
                            action: 'un_notification_get_data_from_algolia',
                            type: $(contentSelector).val(),
                            metro: $(metroSelector).val(),
                            search: params.term
                        };
                    },
                    processResults: function(data) {
                        return {
                            results: $.map(data, function(item) {
                                return {
                                    id: item[0],
                                    text: item[1]
                                };
                            })
                        };
                    },
                    cache: true
                }
            });
        }

        initializeContentSelect2($('.add-event-popup .un-content-id'), '.add-event-popup .un-content-type', '.add-event-popup .un-metro');
        initializeContentSelect2($('.edit-event-popup .un-content-id'), '.edit-event-popup .un-content-type', '.edit-event-popup .un-metro');

        const Calendar = tui.Calendar;
        var cal;

        var CALENDARS = [

        {
            id: "1",
            name: "Company Content Calendar",
            color: CONTENT_CALENDAR_TEXT_COLOR,
            borderColor: CONTENT_CALENDAR_COLOR,
            backgroundColor: CONTENT_CALENDAR_COLOR,
            dragBackgroundColor: CONTENT_CALENDAR_COLOR,
        }

        ];

        // Constants
        var CALENDAR_CSS_PREFIX = "toastui-calendar-";
        var cls = function(className) {
            return CALENDAR_CSS_PREFIX + className;
        };

        // Elements
        var navbarRange = $(".navbar--range");
        var prevButton = $(".prev");
        var nextButton = $(".next");
        var todayButton = $(".today");
        var dropdown = $(".dropdown");
        var dropdownTrigger = $(".dropdown-trigger");
        var dropdownTriggerIcon = $(".dropdown-icon");
        var dropdownContent = $(".dropdown-content");
        var checkboxCollapse = $(".checkbox-collapse");
        var sidebar = $(".sidebar");

        // App State
        var appState = {
            activeCalendarIds: CALENDARS.map(function(calendar) {
                return calendar.id;
            }),
            isDropdownActive: false,
        };

        // functions to handle calendar behaviors
        var loaded = false;

        function reloadEvents() {

            if (!loaded) {
                cal.clear();
            }

            loaded = true;

        }

        function reloadEventsFromGoogle() {
            cal.clear();
        }

        function hide_calendar_by_checkbox() {

            $('.sidebar-item input[type="checkbox"]').each(function() {

                if (!$(this).prop('checked')) {
                    cal.setCalendarVisibility($(this).val(), false);
                }

            });

        }

        function getReadableViewName(viewType) {
            switch (viewType) {
                case "month":
                return "Monthly";
                case "week":
                return "Weekly";
                case "day":
                return "Daily";
                default:
                throw new Error("no view type");
            }
        }

        function displayRenderRange() {
            var rangeStart = cal.getDateRangeStart();
            var rangeEnd = cal.getDateRangeEnd();

            for (var i = 0; i < navbarRange.length; i++) {
                navbarRange[i].textContent = getNavbarRange(
                    rangeStart,
                    rangeEnd,
                    cal.getViewName()
                    );
            }
        }

        function setDropdownTriggerText() {
            var viewName = cal.getViewName();
            var buttonText = $(".dropdown .button-text");
            buttonText[0].textContent = getReadableViewName(viewName);
        }

        function toggleDropdownState() {
            appState.isDropdownActive = !appState.isDropdownActive;
            dropdown[0].classList.toggle("is-active", appState.isDropdownActive);
            dropdownTriggerIcon[0].classList.toggle(
                cls("open"),
                appState.isDropdownActive
                );
        }

        function setAllCheckboxes(checked) {
            var checkboxes = $$('.sidebar-item > input[type="checkbox"]');

            checkboxes.forEach(function(checkbox) {
                checkbox.checked = checked;
                setCheckboxBackgroundColor(checkbox);
            });
        }

        function setCheckboxBackgroundColor(checkbox) {
            var calendarId = checkbox.value;
            var label = checkbox.nextElementSibling;
            var calendarInfo = CALENDARS.find(function(calendar) {
                return calendar.id === calendarId;
            });

            if (!calendarInfo) {
                calendarInfo = {
                    backgroundColor: "#2a4fa7",
                };
            }

            if (label) {
                label.style.setProperty(
                    "--checkbox-" + calendarId,
                    checkbox.checked ? calendarInfo.backgroundColor : "#fff"
                    );
            }
        }

        function update() {
            setDropdownTriggerText();
            displayRenderRange();
            reloadEvents();
        }

        function bindAppEvents() {

            for (var i = 0; i < dropdownTrigger.length; i++) {
                dropdownTrigger[i].addEventListener("click", toggleDropdownState);
            }

            for (var i = 0; i < prevButton.length; i++) {
                prevButton[i].addEventListener("click", function() {
                    cal.prev();
                    update();
                });
            }

            for (var i = 0; i < nextButton.length; i++) {
                nextButton[i].addEventListener("click", function() {
                    cal.next();
                    update();
                });
            }

            for (var i = 0; i < todayButton.length; i++) {
                todayButton[i].addEventListener("click", function() {
                    cal.today();
                    update();
                });
            }

            for (var i = 0; i < dropdownContent.length; i++) {
                dropdownContent[i].addEventListener("click", function(e) {
                    var targetViewName;

                    if ("viewName" in e.target.dataset) {
                        targetViewName = e.target.dataset.viewName;
                        cal.changeView(targetViewName);
                        checkboxCollapse.disabled = targetViewName === "month";
                        toggleDropdownState();
                        update();
                    }
                });
            }

            for (var i = 0; i < checkboxCollapse.length; i++) {
                checkboxCollapse[i].addEventListener("change", function(e) {
                    if ("checked" in e.target) {
                        cal.setOptions({
                            week: {
                                collapseDuplicateEvents: !!e.target.checked,
                            },
                            useDetailPopup: !e.target.checked,
                        });
                    }
                });
            }

            for (var i = 0; i < sidebar.length; i++) {
                sidebar[i].addEventListener("click", function(e) {
                    if ("value" in e.target) {
                        if (e.target.value === "all") {
                            if (appState.activeCalendarIds.length > 0) {
                                cal.setCalendarVisibility(appState.activeCalendarIds, false);
                                appState.activeCalendarIds = [];
                                setAllCheckboxes(false);
                            } else {
                                appState.activeCalendarIds = CALENDARS.map(function(calendar) {
                                    return calendar.id;
                                });
                                cal.setCalendarVisibility(appState.activeCalendarIds, true);
                                setAllCheckboxes(true);
                            }
                        } else if (appState.activeCalendarIds.indexOf(e.target.value) > -1) {
                            appState.activeCalendarIds.splice(
                                appState.activeCalendarIds.indexOf(e.target.value),
                                1
                                );
                            cal.setCalendarVisibility(e.target.value, false);
                            setCheckboxBackgroundColor(e.target);
                        } else {
                            appState.activeCalendarIds.push(e.target.value);
                            cal.setCalendarVisibility(e.target.value, true);
                            setCheckboxBackgroundColor(e.target);
                        }
                    }
                });
            }

        }

        function bindInstanceEvents() {
            cal.on({
                clickMoreEventsBtn: function(btnInfo) {
                    console.log("clickMoreEventsBtn", btnInfo);
                },
                clickEvent: function(eventInfo) {

                    console.log(eventInfo);
                    var editpopup = jQuery('.edit-event-popup');

                    $.ajax({
                        type: 'POST',
                        url: my_ajaxurl.ajax_url,
                        data: {
                            action: 'un_notification_clickEventAction',
                            event_title: eventInfo.event.title
                        },
                        success: function(response) {
                            var eventData = JSON.parse(response);

                            console.log(eventData);
                            jQuery('#edit-event')[0].reset();

                            var assetID = eventData.asset_id;
                            var assetLabel = eventData.asset_label;
                            var contentType = eventData.content_type;
                            var eventContent = eventData.event_content;
                            var scheduleDate = eventData.schedule_datetime;
                            var selectedMetro = eventData.selected_Metro;
                            var eventID = eventData.event_id;
                            var content_url = eventData.content_url;
                            var highlighted_text = eventData.highlighted_text;
                            var notification_type = eventData.notification_type;
                            var users_list = eventData.users_list;
                            var preselect = eventData.users_preselect;

                            console.log('user preselect:', preselect);


                            // var preselect = [
                            //       { id: '460302_12', text: 'User 1' },
                            //     ];



                            let select_users = $('.edit-event-popup .un-users');
                            select_users.empty();

                            if (preselect) {
                                $.each(preselect, function(index, attendee) {
                                    select_users.append(
                                        $("<option></option>")
                                        .attr("value", attendee.id)
                                        .text(attendee.text)
                                        );
                                });

                                select_users.val(preselect.map(attendee => attendee.id)).trigger("change");
                            }


                            $('#edit-event input[name="title"]').val(eventInfo.event.title);
                            $('#edit-event #event-notification').val(eventContent);
                            $('#edit-event #schedule-start-date').val(scheduleDate);
                            $('#edit-event select[name="notification-metro"]').val(selectedMetro);
                            $('#edit-event #notification-content-type').val(contentType + 's');
                            $('#edit-event #edit_event_id').val(eventID);
                            $('#edit-event #delete_event_id').val(eventInfo.event.id);
                            $('#edit-event #delete_calendar_id').val(eventInfo.event.calendarId);
                            $('#edit-event #notification-url-id').val(content_url);
                            $('#edit-event #event-highlighted-text').val(highlighted_text);
                            $('#edit-event input[name="notification-type"][value="' + notification_type + '"]').prop('checked', true);

                            if (notification_type == "all") {

                                $('.content-field').removeClass('hide-field');
                                $('.users-field').addClass('hide-field');

                            } else if (notification_type == "metro") {

                                $('.metro-field').removeClass('hide-field');
                                $('.content-field').removeClass('hide-field');
                                $('.users-field').addClass('hide-field');

                            } else if (notification_type == "users") {

                                $('.users-field').removeClass('hide-field');
                                $('.content-field').removeClass('hide-field');
                                $('.metro-field').addClass('hide-field');

                            }

                            $('.users-field').prop('checked', true);

                            var content_select = $('#edit-event #notification-content-id');
                            content_select.append(new Option(assetLabel, assetID));
                            content_select.val(assetID).trigger('change');

                            editpopup.addClass('show');
                        }
                    });



console.log("clickEvent", eventInfo);
},
clickDayName: function(dayNameInfo) {
    console.log("clickDayName", dayNameInfo);
},
selectDateTime: function(dateTimeInfo) {

    console.log("selectDateTime", dateTimeInfo);
    $('.add-event-popup').addClass('show');

},
beforeCreateEvent: function(event) {
    console.log("beforeCreateEvent", event);

},
beforeUpdateEvent: function(eventInfo) {

    console.log("beforeUpdateEvent", eventInfo);
},
beforeDeleteEvent: function(eventInfo) {
    console.log("beforeDeleteEvent", eventInfo);
},
});
}

function initCheckbox() {
    var checkboxes = $$('input[type="checkbox"]');

    checkboxes.forEach(function(checkbox) {
        setCheckboxBackgroundColor(checkbox);
    });
}

function getEventTemplate(event, isAllday) {
    var html = [];

            // var start = moment(event.start.toDate());
            // if (!isAllday) {
            //     html.push("<strong>" + start.format("HH:mm") + "</strong> ");
            // }

            if (event.isPrivate) {
                html.push('<span class="calendar-font-icon ic-lock-b"></span>');
                html.push(" Private");
            } else {
                if (event.recurrenceRule) {
                    html.push('<span class="calendar-font-icon ic-repeat-b"></span>');
                } else if (event.attendees.length > 0) {
                    html.push('<span class="calendar-font-icon ic-user-b"></span>');
                } else if (event.location) {
                    html.push('<span class="calendar-font-icon ic-location-b"></span>');
                }
                html.push(" " + event.title);
            }

            return html.join("");
        }

        cal = new Calendar("#app", {
            defaultView: "month",
            calendars: CALENDARS,
            isReadOnly: true,
            gridSelection: {
                enableDblClick: false,
                enableClick: false,
            },
            eventFilter: function(event) {
                var currentView = cal.getViewName();
                console.log("EVENT IS ", event);
                if (currentView === "month") {
                    return ["allday", "time"].includes(event.category) && event.isVisible;
                }

                return event.isVisible;
            },
            template: {
                allday: function(event) {
                    return getEventTemplate(event, true);
                },
                time: function(event) {
                    return getEventTemplate(event, false);
                },
            },
        });

        // console.log('Calendars', cal);

        // Init
        bindInstanceEvents();
        bindAppEvents();
        initCheckbox();
        update();


        cal.createEvents(formattedEvents);

        const firstEvent = cal.getEvent('event1', '1');
        const secondEvent = cal.getEvent('event2', '1');

        console.log('firstEvent:', firstEvent);
        console.log('secondEvent:', secondEvent);

        // Delete Event
        jQuery(".delete-event").click(function() {
            console.log('working');
            var eventPostID = jQuery('#edit-event #edit_event_id').val();
            var eventID = jQuery('#edit-event #delete_event_id').val();
            var calendarID = jQuery('#edit-event #delete_calendar_id').val();


            jQuery.ajax({
                type: 'POST',
                url: my_ajaxurl.ajax_url,
                data: {
                    action: 'un_notification_delete_event_action',
                    eventPostID: eventPostID
                },
                success: function(response) {

                    cal.deleteEvent(eventID, calendarID);
                    window.location.reload();
                }
            });

        });

        function removeLastS(str) {
            if (str && str.endsWith("s")) {
                return str.slice(0, -1);
            }
            return str;
        }

        // add event script

        $('#add-event').submit(function(e) {
            e.preventDefault(); // Prevent the default form submission behavior

            // Get notification type
            let notification_type = $('.add-event-popup input[name="notification-type"]:checked').val();

            // Get selected users
            let selectedUsers = $('.add-event-popup select[name="notification-users"]').val();

            console.log($('.add-event-popup select[name="notification-users"]').select2('data'));

            // Get the selected metro value
            let selectedMetro = $('.add-event-popup .un-metro').val();
            let scheduleDate = $('.add-event-popup input[name="schedule_start_date"]').val();

            // Get the selected content type and content ID
            let selectedContentType = removeLastS($('.add-event-popup [name="notification-content-type"]').val());
            let selectedContentId = $('.add-event-popup [name="notification-content-id"]').val();
            let selectedContentLabel = $('.add-event-popup [name="notification-content-id"]').find('option:selected').text();
            let notificationUrl = $('.add-event-popup [name="notification-url"]').val();
            let highlighted_text = $('.add-event-popup [name="event-highlighted-text"]').val();

            const notificationDataArry = {
                'title': $('.add-event-popup input[name="title"]').val(),
                'body': $('.add-event-popup [name="event-notification"]').val(),
                'notification_type': notification_type,
                'users_list': selectedUsers,
                'content_type': selectedContentType,
                'asset_id': selectedContentId,
                'asset_label': selectedContentLabel,
                'selectedMetro': selectedMetro,
                'scheduleDate': scheduleDate,
                'notificationUrl': notificationUrl,
                'highlighted_text': highlighted_text
            };

            console.log(notificationDataArry);

            $.ajax({
                type: 'POST',
                url: my_ajaxurl.ajax_url,
                data: {
                    action: 'un_notification_createNotification',
                    notificationData: notificationDataArry
                },
                success: function(response) {
                    setTimeout(function() {
                        $('#add-event')[0].reset();
                        submitButton.prop('disabled', false);
                        submitButton.css('opacity', '1');
                        $('#add-event .save-event .toastui-calendar-template-popupSave').text('Send');
                    }, 5000);
                    $('.add-event-popup').removeClass('show');

                    window.location.reload();
                }
            });


            // Disable the submit button and reduce its opacity
            const submitButton = $('#add-event .save-event');
            submitButton.prop('disabled', true);
            submitButton.css('opacity', '0.5');

        });

        // Update event script

        $('#edit-event').submit(function(e) {
            e.preventDefault(); // Prevent the default form submission behavior

            // Get the selected metro value
            const selectedMetro = $('#edit-event .un-metro').val();
            const scheduleDate = $('#edit-event #schedule-start-date').val();
            const event_post_id = $('#edit_event_id').val();

            let notification_type = $('.edit-event-popup input[name="notification-type"]:checked').val();

            let selectedUsers = $('.edit-event-popup select[name="notification-users"]').val();

            console.log('selectedUsers:', selectedUsers);

            // Get the selected content type and content ID
            let selectedContentType = removeLastS($(this).find('#notification-content-type').val());
            let selectedContentId = $('#edit-event #notification-content-id').val();
            let selectedContentLabel = $('#notification-content-id').find('option:selected').text();
            let selectedContentUrl = $('#edit-event #notification-url-id').val();
            let highlighted_text = $('#edit-event #event-highlighted-text').val();



            const notificationDataArry = {
                'title': $('#edit-event input[name="title"]').val(),
                'body': $('#edit-event #event-notification').val(),
                'content_type': selectedContentType,
                'notification_type': notification_type,
                'users_list': selectedUsers,
                'asset_id': selectedContentId,
                'asset_label': selectedContentLabel,
                'selectedMetro': selectedMetro,
                'scheduleDate': scheduleDate,
                'event_post_id': event_post_id,
                'content_url': selectedContentUrl,
                'highlighted_text': highlighted_text
            };


            $.ajax({
                type: 'POST',
                url: my_ajaxurl.ajax_url,
                data: {
                    action: 'un_notification_updateNotification',
                    notificationData: notificationDataArry
                },
                success: function(response) {
                    setTimeout(function() {
                        $('#add-event')[0].reset();
                        submitButton.prop('disabled', false);
                        submitButton.css('opacity', '1');
                        $('#add-event .save-event .toastui-calendar-template-popupSave').text('Send');
                    }, 5000);
                    $('.add-event-popup').removeClass('show');

                    window.location.reload();
                }
            });


            // Disable the submit button and reduce its opacity
            // const submitButton = $('#add-event .save-event');
            // submitButton.prop('disabled', true);
            // submitButton.css('opacity', '0.5');
        });


        $('.send-notification-now').click(function(e) {

            e.preventDefault(); // Prevent the default form submission behavior

            $("#schedule-start-date").removeAttr("required");

            var addEvent = document.getElementById('add-event');

            if (!addEvent.reportValidity()) {
                $("#schedule-start-date").attr("required", "required");
                return;
            } else {
                $("#schedule-start-date").attr("required", "required");
            }

            // Get the selected metro value
            const selectedMetro = $('.un-metro').val();
            const scheduleDate = $('#schedule-start-date').val();

            // Get the selected content type and content ID
            let selectedContentType = removeLastS($('#notification-content-type').val());
            let selectedContentId = $('#notification-content-id').val();
            let notificationUrl = $('#notification-url-id').val();
            let highlighted_text = $('#event-highlighted-text').val();

            let asset_id = selectedContentId;
            if (notificationUrl && (selectedContentType == 'product' || selectedContentType == 'company')) asset_id = notificationUrl;

            // Get the users
            let selectedUsers = $('#notification-users').val();

            // Get the current domain
            const currentDomain = window.location.origin;

            // Define the API endpoint URL based on metro selection and selected users
            let apiUrl;
            if (selectedUsers.length > 0) {
                apiUrl = `${currentDomain}/wp-json/unation-aws-api/send-notification-to-list-of-users`;
            } else if (selectedMetro !== '') {
                apiUrl = `${currentDomain}/wp-json/unation-aws-api/send-notification-to-loc`;
            } else {
                apiUrl = `${currentDomain}/wp-json/unation-aws-api/send-notification-to-all`;
            }

            //Prepare the notification data
            const notificationData = {
                title: $('input[name="title"]').val(),
                body: $('#event-notification').val(),
                imageURL: '',
                extraParams: {
                    type: selectedContentType,
                    asset_id: asset_id,
                    highlighted_text: highlighted_text
                },
            };

            if (selectedUsers.length > 0) {
                notificationData.list = selectedUsers;
            } else if (selectedMetro !== '') {
                notificationData.city = selectedMetro;
            }

            console.log('API URL', apiUrl);
            console.log('NotificationData:', notificationData);

            const submitButton = $('#add-event .send-notification-now');
            submitButton.prop('disabled', true);
            submitButton.css('opacity', '0.5');

            $('#add-event .send-notification-now .toastui-calendar-template-popupSave').text('Sending');

            //Send the notification
            sendPostRequest(apiUrl, notificationData)
            .then((response) => {

                console.log('Notification Response:', response);

                    // Update the submit button text to "Sent" on success
                    $('#add-event .send-notification-now .toastui-calendar-template-popupSave').text('Sent');
                    // Reset the form after 5 seconds delay
                    setTimeout(function() {
                        submitButton.prop('disabled', false);
                        submitButton.css('opacity', '1');
                        $('#add-event .send-notification-now .toastui-calendar-template-popupSave').text('Send');
                    }, 5000);

                })
            .catch((error) => {
                console.error('Error:', error);
            });

        });


        async function sendPostRequest(url, data) {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data),
            });
            const responseData = await response.json();
            return responseData;
        }

        $(".navbar .round-button").click(function() {
            $('#add-event')[0].reset();
            $('#notification-content-id').empty().trigger('change');
            $("input[name='notification-type'][value='all']").prop('checked', true).trigger('change');
            $('.add-event-popup').addClass('show');
        });


    });


var $ = jQuery;

jQuery(document).ready(function($) {
    // After adding the dynamic element, call the select2 initialization only for the new, un-initialized elements
        console.log('select 2 not working');
        $('.mySelect').select2();
        console.log('select 2 working');

        $('.add-un-content-type').select2({
            multiple: false,
        });

        $('.add-un-metro').select2({
            multiple: false,
        });

});

jQuery(document).on("change", ".mySelect", function() {

    var selectedVal = $(this).val();
    if( selectedVal.length <= 0 ) return;

    var selectedOptionsDiv = $(this).parent().parent().siblings("div.selectedOptions");
    selectedOptionsDiv.find('ul').remove();

    $(this).find(":selected").each(function() {
        var selectedOption = $(this).text();
        selectedOptionsDiv.append(`<ul><li>` + selectedOption + `<span class="rm-item" style="float: right;cursor: pointer;"><img style="border-radius: 15px;" src="<?php echo site_url(); ?>/wp-content/plugins/unation-marketing-emails/img/Vector.svg" alt=""></span></li></ul>`);
    });

    $(this).prop("disabled", true);

    console.log($(this).val());

    var mySelect = this; // Store the reference to the current select element

    // Event handler for removing the item
    selectedOptionsDiv.on("click", ".rm-item", function() {
        // Get the parent ul element and remove it
        $(this).closest('ul').remove();

        // Enable the corresponding select element
        $(mySelect).prop("disabled", false);

        // Empty the select value
        $(mySelect).val('');

        // Trigger the change event to update the selectedOptions div
        $(mySelect).change();
    });
});



jQuery(document).ready(function($) {
    // Function to update character count and display error if needed
    function checkCharacterLimit(inputField) {
        var characterLimit = parseInt(inputField.attr("maxlength"));
        var currentLength = inputField.val().length;

        var container = inputField.closest(".unef-field-item");
        var characterCountElement = container.find(".character-limit span");
        var errorElement = container.find(".error-msg");

        characterCountElement.text(currentLength);

        if (currentLength > characterLimit) {
            characterCountElement.addClass("error");
            errorElement.show();
        } else {
            characterCountElement.removeClass("error");
            errorElement.hide();
        }
    }

    // Bind the input event to all input fields with maxlength attribute within a specific container (e.g., a form)
    $(".event-popup").on("input", "input[maxlength]", function() {
        checkCharacterLimit($(this));
    });

    // Initial check on page load for all input fields within the form
    $(".event-popup input[maxlength]").each(function() {
        checkCharacterLimit($(this));
    });
});


</script>