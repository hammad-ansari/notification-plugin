<?php
/*
Plugin Name: UNATION Notifications
Description: This plugin creates a custom post type named Notifications.
Version: 1.0
Author: Hammad Ansari
*/

if (!defined('ABSPATH'))
	exit; // Exit if accessed directly

/**
 * Define Plugin URL and Directory Path
 */
define('UNATION_NOTIFICATIONS_URL', plugins_url('/', __FILE__));  // Define Plugin URL
define('UNATION_NOTIFICATIONS_PATH', plugin_dir_path(__FILE__));  // Define Plugin Directory Path

/**
 * Register a Calendar menu page.
 */

if (!function_exists('register_un_notifications_menu')) {

	function register_un_notifications_menu()
	{

		add_menu_page(
			__('Notifications Calendar', 'unation-notifications'),
			'Notifications Calendar',
			'edit_posts',
			'un_notifications',
			'un_notifications_func',
			'dashicons-calendar-alt',
			9.6
		);
	}
	add_action('admin_menu', 'register_un_notifications_menu');
}

if (!function_exists('un_notifications_func')) {
	function un_notifications_func()
	{

		include('unation-notifications-calendar.php');
	}
}

// Register Custom Post Type Notification
if (!function_exists('un_create_notification_cpt')) {
	function un_create_notification_cpt()
	{

		$labels = array(
			'name' => _x('Notifications', 'Post Type General Name', 'textdomain'),
			'singular_name' => _x('Notification', 'Post Type Singular Name', 'textdomain'),
			'menu_name' => _x('Notifications', 'Admin Menu text', 'textdomain'),
			'name_admin_bar' => _x('Notification', 'Add New on Toolbar', 'textdomain'),
			'archives' => __('Notification Archives', 'textdomain'),
			'attributes' => __('Notification Attributes', 'textdomain'),
			'parent_item_colon' => __('Parent Notification:', 'textdomain'),
			'all_items' => __('All Notifications', 'textdomain'),
			'add_new_item' => __('Add New Notification', 'textdomain'),
			'add_new' => __('Add New', 'textdomain'),
			'new_item' => __('New Notification', 'textdomain'),
			'edit_item' => __('Edit Notification', 'textdomain'),
			'update_item' => __('Update Notification', 'textdomain'),
			'view_item' => __('View Notification', 'textdomain'),
			'view_items' => __('View Notifications', 'textdomain'),
			'search_items' => __('Search Notification', 'textdomain'),
			'not_found' => __('Not found', 'textdomain'),
			'not_found_in_trash' => __('Not found in Trash', 'textdomain'),
			'featured_image' => __('Featured Image', 'textdomain'),
			'set_featured_image' => __('Set featured image', 'textdomain'),
			'remove_featured_image' => __('Remove featured image', 'textdomain'),
			'use_featured_image' => __('Use as featured image', 'textdomain'),
			'insert_into_item' => __('Insert into Notification', 'textdomain'),
			'uploaded_to_this_item' => __('Uploaded to this Notification', 'textdomain'),
			'items_list' => __('Notifications list', 'textdomain'),
			'items_list_navigation' => __('Notifications list navigation', 'textdomain'),
			'filter_items_list' => __('Filter Notifications list', 'textdomain'),
		);
		$args = array(
			'label' => __('Notification', 'textdomain'),
			'description' => __('', 'textdomain'),
			'labels' => $labels,
			'menu_icon' => 'dashicons-admin-comments',
			'supports' => array('title', 'editor', 'thumbnail'),
			'taxonomies' => array(),
			'public' => true,
			'show_ui' => true,
			'show_in_menu' => true,
			'menu_position' => 5,
			'show_in_admin_bar' => true,
			'show_in_nav_menus' => true,
			'can_export' => true,
			'has_archive' => true,
			'hierarchical' => false,
			'exclude_from_search' => false,
			'show_in_rest' => true,
			'publicly_queryable' => true,
			'capability_type' => 'post',
		);
		register_post_type('notification', $args);
	}
}
add_action('init', 'un_create_notification_cpt', 0);


// get data from algolia
if (!function_exists('un_notification_get_data_from_algolia')) {
	function un_notification_get_data_from_algolia()
	{

		$search = isset($_GET['search']) ? $_GET['search'] : '';
		$type   = isset($_GET['type']) ? $_GET['type'] : '';
		$metro  = isset($_GET['metro']) ? $_GET['metro'] : '';

		if (empty($search) || empty($type)) return;

		global $unawsAlgoliaQueryObj;
		$algoliaIndex = $unawsAlgoliaQueryObj;

		$options = array();

		if (!empty($metro)) {
			global $wpdb;
			$metro_coords = $wpdb->get_results("SELECT `lat`, `lng` FROM `wp_curated_cities` WHERE `city_name` LIKE '%" . $metro . "%'");

			$latitude = $metro_coords[0]->lat;
			$longitude = $metro_coords[0]->lng;
			$distance = 80; // in km

			$options = array(
				"facetFilters" => array(
					"type:" . $type
				)
			);

			$options['aroundLatLng'] = $latitude . ', ' . $longitude;
			$options['aroundRadius'] = ($distance / 2) * 1000;
		} else {

			$options = array(
				"facetFilters" => array(
					"type:" . $type
				)
			);
		}

		$result = $algoliaIndex->search($search, $options);

		$hits = $result["hits"];

		$results = array();
		foreach ($hits as $hit) {
			array_push($results, array(
				$hit["id"],
				$hit["name"]
			));
		}

		echo json_encode($results);
		wp_die();
	}
}
add_action('wp_ajax_nopriv_un_notification_get_data_from_algolia', 'un_notification_get_data_from_algolia');
add_action('wp_ajax_un_notification_get_data_from_algolia', 'un_notification_get_data_from_algolia');

// get users data from algolia
if (!function_exists('un_notification_get_users_data_from_algolia')) {
	function un_notification_get_users_data_from_algolia()
	{

		$search = isset($_GET['search']) ? $_GET['search'] : '';

		if (empty($search)) return;

		global $unawsAlgoliaQueryObj;
		$algoliaIndex = $unawsAlgoliaQueryObj;

		$options = array(
			"facetFilters" => array(
				"type:Profiles", "roles:-individual", "roles:-verified_users"
			)
		);

		$result = $algoliaIndex->search($search, $options);

		$hits = $result["hits"];

		$results = array();
		foreach ($hits as $hit) {
			if( !empty( trim($hit["name"]) ) ) {
				array_push($results, array(
					$hit["objectID"],
					$hit["name"] . " ( " . $hit["user_name"] . " )"
				));
			} else {
				array_push($results, array(
					$hit["objectID"],
					$hit["user_name"]
				));
			}
		}

		echo json_encode($results);
		wp_die();

	}
}
add_action('wp_ajax_nopriv_un_notification_get_users_data_from_algolia', 'un_notification_get_users_data_from_algolia');
add_action('wp_ajax_un_notification_get_users_data_from_algolia', 'un_notification_get_users_data_from_algolia');

// create notification
if (!function_exists('un_notification_createNotification')) {
	function un_notification_createNotification()
	{
		$notificationData = $_POST['notificationData'];
		$title = $notificationData['title'];
		$body = $notificationData['body'];
		$content_type = $notificationData['content_type'];
		$asset_id = $notificationData['asset_id'];
		$asset_label = $notificationData['asset_label'];
		$selectedMetro = $notificationData['selectedMetro'];
		$scheduleDate = $notificationData['scheduleDate'];
		$notificationUrl = $notificationData['notificationUrl'];
		$highlighted_text = $notificationData['highlighted_text'];
		$notification_type = $notificationData['notification_type'];

		$users_name_ids = array();

		foreach ($notificationData['users_list'] as $key => $users_id) {
			
			global $unawsAlgoliaQueryObj;
			$algoliaIndex = $unawsAlgoliaQueryObj;

			$result = $algoliaIndex->search('', array(
                                    "facetFilters" => array(
                                        "type:Profiles",
                                        "roles:-individual",
                                        "roles:-verified_users",
                                        "objectID:".$users_id
                                    )
                                ));

			$filtered_users = $result["hits"];

			foreach ($filtered_users as $key => $value) {
				
				$objectID =	$value["objectID"];
				$users_name =	$value["name"] . " ( " . $value["user_name"] . " )";

				$users_name_ids[] = array('id' => $objectID, 'text' => $users_name);
			}

		}
		
		print_r($users_name_ids);

		$users_list = json_encode($notificationData['users_list']);
		$users_preselect = json_encode($users_name_ids);

		$new_notification = array(
			'post_title'    => $title,
			'post_content'  => $body,
			'post_status'   => 'publish',
			'post_type'     => 'notification'
		);

		// Insert the post into the database
		$post_id = wp_insert_post($new_notification);

		if ($post_id) {
			// Add custom post meta
			update_post_meta($post_id, 'content_type', $content_type, true);
			update_post_meta($post_id, 'asset_id', $asset_id, true);
			update_post_meta($post_id, 'asset_label', $asset_label, true);
			update_post_meta($post_id, 'schedule_datetime', $scheduleDate, true);
			update_post_meta($post_id, 'selected_Metro', $selectedMetro, true);
			update_post_meta($post_id, 'content_url', $notificationUrl, true);
			update_post_meta($post_id, 'highlighted_text', $highlighted_text, true);
			update_post_meta($post_id, 'notification_type', $notification_type, true);
			update_post_meta($post_id, 'users_list', $users_list, true);
			update_post_meta($post_id, 'users_preselect', $users_preselect, true);
		}

		wp_die();
	}
}
add_action('wp_ajax_un_notification_createNotification', 'un_notification_createNotification');

// update notification
if (!function_exists('un_notification_updateNotification')) {
	function un_notification_updateNotification()
	{

		$notificationData = $_POST['notificationData'];
		$title = $notificationData['title'];
		$body = $notificationData['body'];
		$content_type = $notificationData['content_type'];
		$asset_id = $notificationData['asset_id'];
		$asset_label = $notificationData['asset_label'];
		$selectedMetro = $notificationData['selectedMetro'];
		$scheduleDate = $notificationData['scheduleDate'];
		$event_post_id = $notificationData['event_post_id'];
		$content_url = $notificationData['content_url'];
		$highlighted_text = $notificationData['highlighted_text'];
		$notification_type = $notificationData['notification_type'];
		$users_list = json_encode($notificationData['users_list']);

		$users_name_ids = array();

		foreach ($notificationData['users_list'] as $key => $users_id) {
			
			global $unawsAlgoliaQueryObj;
			$algoliaIndex = $unawsAlgoliaQueryObj;

			$result = $algoliaIndex->search('', array(
                                    "facetFilters" => array(
                                        "type:Profiles",
                                        "roles:-individual",
                                        "roles:-verified_users",
                                        "objectID:".$users_id
                                    )
                                ));

			$filtered_users = $result["hits"];

			foreach ($filtered_users as $key => $value) {
				
				$objectID =	$value["objectID"];
				$users_name =	$value["name"] . " ( " . $value["user_name"] . " )";

				$users_name_ids[] = array('id' => $objectID, 'text' => $users_name);
			}

		}

		$users_preselect = json_encode($users_name_ids);

	

		update_post_meta($event_post_id, 'content_type', $content_type);
		update_post_meta($event_post_id, 'asset_id', $asset_id);
		update_post_meta($event_post_id, 'asset_label', $asset_label);
		update_post_meta($event_post_id, 'schedule_datetime', $scheduleDate);
		update_post_meta($event_post_id, 'selected_Metro', $selectedMetro);
		update_post_meta($event_post_id, 'content_url', $content_url);
		update_post_meta($event_post_id, 'highlighted_text', $highlighted_text);
		update_post_meta($event_post_id, 'notification_type', $notification_type);
		update_post_meta($event_post_id, 'users_list', $users_list);
		update_post_meta($event_post_id, 'users_preselect', $users_preselect);

		$event_post = array(
			'ID'           => $event_post_id,
			'post_title'   => $title, // new title
			'post_content' => $body, // new content
		);

		// Update the post into the database
		$result = wp_update_post($event_post);

		if (is_wp_error($result)) {
			// The post was not updated successfully
			echo 'Error updating post';
		} else {
			// Post updated successfully
			echo 'Post updated successfully';
		}


		wp_die();
	}
}
add_action('wp_ajax_un_notification_updateNotification', 'un_notification_updateNotification');

// add notifcation schedular
if (!function_exists('un_schedule_notification_checker')) {
	function un_schedule_notification_checker()
	{
		if (!wp_next_scheduled('un_notification_checker_event')) {
			// Calculate the next 5-minute interval
			$next_interval = ceil(time() / 300) * 300;

			// Schedule the event to run every 5 minutes
			wp_schedule_event($next_interval, '5minutes', 'un_notification_checker_event');
		}
	}

	add_filter('cron_schedules', function ($schedules) {
		$schedules['5minutes'] = array(
			'interval' => 300,
			'display'  => __('Every 5 minutes')
		);
		return $schedules;
	});
}
add_action('wp', 'un_schedule_notification_checker');

if (!function_exists('un_check_and_send_notifications')) {
	function un_check_and_send_notifications()
	{

		date_default_timezone_set('America/New_York'); // Set the default timezone to Eastern Standard Time (EST)

		global $wpdb;

		$query = "
			SELECT p.*
			FROM {$wpdb->prefix}posts AS p
			INNER JOIN {$wpdb->prefix}postmeta AS pm ON p.ID = pm.post_id
			WHERE p.post_type = 'notification'
				AND p.post_status = 'publish'
				AND (
					(pm.meta_key = 'schedule_datetime' AND pm.meta_value <= %s)
				)
				AND (
					(pm.meta_key = 'notification_processed' AND pm.meta_value = '')
					OR NOT EXISTS (
						SELECT *
						FROM {$wpdb->prefix}postmeta AS pm2
						WHERE p.ID = pm2.post_id
							AND pm2.meta_key = 'notification_processed'
					)
				)
		";

		$current_time = current_time('Y-m-d\TH:i');
		$query = $wpdb->prepare($query, $current_time);

		// $query = "
		// 	SELECT p.*
		// 	FROM {$wpdb->prefix}posts AS p
		// 	WHERE p.post_type = 'notification'
		// 		AND p.post_status = 'publish'
		// ";
		// $query = $wpdb->prepare($query);

		$notifications = $wpdb->get_results($query);

		// For each notification, send the post request
		foreach ($notifications as $notification) {
			$notification_id       = $notification->ID;
			$notification_asset_id = '';
			$title                 = get_the_title($notification_id);
			$description           = $notification->post_content;
			$content_type          = get_post_meta($notification->ID, 'content_type', true);
			$asset_id              = get_post_meta($notification->ID, 'asset_id', true);
			$scheduled_time        = get_post_meta($notification->ID, 'schedule_datetime', true);
			$selected_Metro        = get_post_meta($notification->ID, 'selected_Metro', true);
			$content_url           = get_post_meta($event_id, 'content_url', true);
			$highlighted_text      = get_post_meta($notification->ID, 'highlighted_text', true);
			$users_list      	   = get_post_meta($notification->ID, 'users_list', true);

			$users_array = json_decode($users_list);

			if (!empty($content_url) && ( $content_type == 'product' || $content_type == 'company' ) ) {
				$notification_asset_id = $content_url;
			} else {
				$notification_asset_id = $asset_id;
			}

			$currentDomain = get_site_url();
			$apiUrl = '';
            if (!empty($users_array)) {
                $apiUrl = $currentDomain.'/wp-json/unation-aws-api/send-notification-to-list-of-users';
            } else if (!empty($selected_Metro)) {
                $apiUrl = $currentDomain.'/wp-json/unation-aws-api/send-notification-to-loc';
            } else {
                $apiUrl = $currentDomain.'/wp-json/unation-aws-api/send-notification-to-all';
            }

			$notificationData = array(
				'title'        => $title,
				'body'         => $description,
				'imageURL'     => '',
				'extraParams'  => array(
					'type'             => $content_type,
					'asset_id'         => $notification_asset_id,
					'highlighted_text' => $highlighted_text
				)
			);

			if( $users_array && count($users_array) > 0 ) {
				$notificationData['list'] = $users_array;
			} else if ( !empty($selected_Metro) ) {
				$notificationData['city'] = $selected_Metro;
			}

			$request_body = wp_json_encode($notificationData);
			update_post_meta($notification_id, 'notification_request_body', $request_body);

			$response = wp_remote_post($apiUrl, array(
				'headers' => array(
					'Content-Type' => 'application/json',
				),
				'body'    => $request_body,
			));

			if (is_wp_error($response)) {
				// Handle error condition
				continue; // Skip to the next notification
			}

			$response_data = json_decode(wp_remote_retrieve_body($response));

			// Store the notification_processed meta value
			update_post_meta($notification_id, 'notification_processed', 'response_received');

			$response_data = $response_data->result;

			// Save response data to postmeta
			if (isset($response_data->status)) {
				update_post_meta($notification_id, 'notification_status', $response_data->status);
			}
	
			if (isset($response_data->message)) {
				update_post_meta($notification_id, 'notification_message', $response_data->message);
			}
	
			if (isset($response_data->data)) {
				$data = json_decode($response_data->data->data, true);
				if (isset($data['multicast_id'])) {
					update_post_meta($notification_id, 'notification_multicast_id', $data['multicast_id']);
				}
				if (isset($data['success'])) {
					update_post_meta($notification_id, 'notification_success_count', $data['success']);
				}
				if (isset($data['failure'])) {
					update_post_meta($notification_id, 'notification_failure_count', $data['failure']);
				}
				if (isset($data['results'])) {
					update_post_meta($notification_id, 'notification_results', $data['results']);
				}
			}

		}
	}
}
add_action('un_notification_checker_event', 'un_check_and_send_notifications');

if (!function_exists("un_notification_clickEventAction")) {
	function un_notification_clickEventAction()
	{

		$event_title = $_POST['event_title'];

		$event = get_page_by_title($event_title, OBJECT, 'notification');
		$event_id = $event->ID;

		$event_content = $event->post_content;
		$content_type = get_post_meta($event_id, 'content_type', true);
		$asset_id = get_post_meta($event_id, 'asset_id', true);
		$asset_label = get_post_meta($event_id, 'asset_label', true);
		$schedule_datetime = get_post_meta($event_id, 'schedule_datetime', true);
		$selected_Metro = get_post_meta($event_id, 'selected_Metro', true);
		$content_url = get_post_meta($event_id, 'content_url', true);
		$highlighted_text = get_post_meta($event_id, 'highlighted_text', true);
		$notification_type = get_post_meta($event_id, 'notification_type', true);
		$users_list      = get_post_meta($event_id, 'users_list', true);
		$users_preselect   = get_post_meta($event_id, 'users_preselect', true);

		$event_data = array(
			'event_content' => $event_content,
			'content_type' => $content_type,
			'asset_id' => $asset_id,
			'asset_label' => $asset_label,
			'schedule_datetime' => $schedule_datetime,
			'selected_Metro' => $selected_Metro,
			'event_id' => $event_id,
			'content_url' => $content_url,
			'highlighted_text' => $highlighted_text,
			'notification_type' => $notification_type,
			'users_list' => $users_list,
			'users_preselect' => json_decode($users_preselect, true)
		);

		echo json_encode($event_data);

		wp_die();
	}
}
add_action('wp_ajax_un_notification_clickEventAction', 'un_notification_clickEventAction');


if (!function_exists("un_notification_delete_event_action")) {
	function un_notification_delete_event_action()
	{

		$eventPostID = $_POST['eventPostID'];

		$deleteEvent = wp_delete_post($eventPostID);

		if ($deleteEvent !== false) {
			echo "Post with ID {$post_id} was deleted successfully.";
		} else {
			echo "Failed to delete the post with ID {$post_id}. It may not exist.";
		}

		wp_die();
	}
}
add_action('wp_ajax_un_notification_delete_event_action', 'un_notification_delete_event_action');
