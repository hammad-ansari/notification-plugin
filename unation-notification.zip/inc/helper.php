<script>
    jQuery(document).ready(function ($) {

        $('#adminmenuback').click();

        toastr.options.closeButton = true;

        $('.event-popup-close-link').click(function(){  
            $('#add-event').trigger("reset");

            $('.assets .column-2').each(function() {
                $(this).remove();
            });

            $('.add-event-popup input[name="event_id"]').val("");
            
            $('.event-popup').removeClass('show');
            $('.add-event-popup .form-row #calendar').show();
        });

        // Autocomplete event address
        // var location_address_input_id = jQuery('#event-location').attr('id');
        // var location_address = document.getElementById(location_address_input_id);
        // if (location_address) {
        //     var autocomplete = new google.maps.places.Autocomplete(location_address);
        // }
    });
</script>