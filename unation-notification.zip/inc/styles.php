<style>
    .app-container,
    .content {
        height: 100vh;
        padding: 0px;
    }

    #screen-meta-links {
        display: none !important;
    }

    #wpwrap.open-menu #wpcontent {
        margin-left: 40px !important;
    }

    .sidebar-item .checkbox,
    .sidebar-item .radio {
        display: inline;
    }

    .toastui-calendar-dropdown-section.toastui-calendar-calendar-section {
        width: 220px;
    }

    .toastui-calendar-popup-section-title {
        width: 100%;
    }

    .toastui-calendar-popup-section-private,
    .toastui-calendar-state-section {
        display: none;
    }

    .toastui-calendar-popup-section:has(.toastui-calendar-popup-section-location),
    .toastui-calendar-detail-item:has(.toastui-calendar-ic-user-b),
    .toastui-calendar-detail-item:has(.toastui-calendar-ic-state-b) {
        display: none;
    }

    .toastui-calendar-popup-container {
        z-index: 9999;
    }

    .toastui-calendar-panel.toastui-calendar-milestone,
    .toastui-calendar-panel.toastui-calendar-task,
    .toastui-calendar-panel-resizer {
        display: none !important;
    }

    .toastui-calendar-grid-cell-date .toastui-calendar-weekday-grid-date.toastui-calendar-weekday-grid-date-decorator {
        background: linear-gradient(90deg, #F5286E 0%, #FC6D43 88.61%);
        color: #fff !important;
    }

    .toastui-calendar-grid-cell-more-events,
    .toastui-calendar-grid-cell-more-events span {
        display: inline-block;
        background: linear-gradient(90deg, #F5286E 0%, #FC6D43 88.61%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        text-fill-color: transparent;
    }

    .toastui-calendar-template-monthDayName,
    .toastui-calendar-weekday-grid-date.toastui-calendar-template-monthGridHeader {
        font-family: 'Lato';
        font-style: normal;
        font-weight: 600;
        font-size: 11px;
        text-transform: uppercase;
        color: #79808A;
    }

    .toastui-calendar-see-more-container {
        z-index: 99 !important;
    }

    /* Navbar */
    .navbar,
    .navbar .button,
    .navbar .navbar--range {
        font-family: 'Montserrat' !important;
        font-style: normal !important;
        font-weight: 600 !important;
        font-size: 14px !important;
        line-height: 17px !important;
        color: #000 !important;
    }

    .navbar .left,
    .navbar .right {
        flex: 1;
        display: flex;
        align-items: center;
    }

    .navbar .right {
        justify-content: end;
    }

    .navbar .dropdown {
        margin-right: 0;
    }

    .navbar .text,
    .navbar .button {
        margin-right: 8px;
    }

    .navbar .navbar--range {
        margin-left: 0px;
    }

    .navbar .button {
        border: 1px solid #DCDEE0;
    }

    .navbar .button+.button {
        display: flex;
    }

    .navbar .button.prev {
        margin-right: 0px;
        border-top-right-radius: 0px;
        border-bottom-right-radius: 0px;
    }

    .navbar .button.next {
        margin-left: 0px;
        border-top-left-radius: 0px;
        border-bottom-left-radius: 0px;
    }

    .navbar .round-button {
        background: linear-gradient(90deg, #F5286E 0%, #FC6D43 88.61%);
        border-radius: 50%;
        width: 34px;
        height: 34px;
        border: none;
        cursor: pointer;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .navbar .plus-sign {
        font-size: 22px;
        color: white;
    }

    /* Navbar End */

    /* SumoSelect Start */

    .SumoSelect,
    .SumoSelect .select-all {
        font-family: 'Montserrat' !important;
        font-style: normal !important;
        font-weight: 600 !important;
        font-size: 12px !important;
        color: #000 !important;
    }

    .SumoSelect p.SelectBox {
        display: block !important;
        margin-bottom: 0px !important;
    }

    .SumoSelect .select-all {
        padding: 6px 6px 6px 35px !important;
        margin-bottom: 0px !important;
        border-bottom: 1px solid #f5f5f5 !important;
        height: auto !important;
    }

    /* SumoSelect End */

    .event-body .description {
        color: black;
        font-size: 13px;
        display: block;
        padding: 5px 0px;
    }

    .event-body .morelink {
        display: block;
    }

    .event-body .morelink:focus {
        box-shadow: none;
    }

    .event-body ul.attendees-list {
        display: none;
    }

    .event-body #profile-picture-container {
        margin-top: 5px;
    }

    .event-body #profile-picture-container .circle {
        display: inline-block;
        width: 24px;
        height: 24px;
        border-radius: 50%;
        overflow: hidden;
        border: 1px solid #FFFFFF;
        margin-right: -5px;
    }

    .event-body #profile-picture-container .circle img {
        width: 100%;
        height: auto;
    }

    .event-body #profile-picture-container .circle:hover:after {
        content: attr(data-username);
        position: absolute;
        color: black;
        padding: 5px;
        white-space: nowrap;
        background: #FFFFFF;
        box-shadow: 0px 5px 20px rgb(11 7 110 / 7%);
        border-radius: 4px;
        font-size: 12px;
    }


    /* Event Popup CSS */
    .event-popup {
        width: 100%;
        height: auto;
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-items: center;
        align-content: center;
        position: fixed;
        left: 0;
        top: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.25);
        z-index: 111;
        opacity: 0;
        visibility: hidden;
        transition: all 0.3s ease-in-out 0s;
        text-align: left;
    }

    .event-popup.show {
        opacity: 1;
        visibility: visible;
    }

    .event-popup .event-popup-inn {
        background: #FFFFFF;
        border-radius: 10px;
        width: 92%;
        max-height: 95%;
        overflow: scroll;
        max-width: 800px;
        margin: 0 auto;
        display: block;
        box-sizing: border-box;
        padding: 28px 26px;
        position: relative;
    }

    .event-details-popup .event-popup-inn {
        max-width: 500px;
    }

    .event-popup .hide-field {
        display: none!important;
    }

    .event-popup .event-popup-inn .event-popup-close {
        width: 30px;
        height: 30px;
        position: absolute;
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-items: center;
        align-content: center;
        right: 26px;
        top: 26px;
        cursor: pointer;
    }

    .event-popup .event-popup-inn .event-popup-close img {
        display: block;
    }

    .event-popup .event-popup-inn .event-popup-heading {
        width: 100%;
        display: flex;
        justify-content: space-between;
    }

    .event-popup .event-popup-inn .event-popup-heading h3.event-title {
        font-family: 'Montserrat';
        font-style: normal;
        font-weight: 700;
        font-size: 20px;
        line-height: 24px;
        color: #1E1F22;
        display: block;
        margin: 0;
        padding-bottom: 20px;
    }

    .event-popup .event-popup-inn p.sub_heading {
        margin-bottom: 16px;
    }

    .event-popup .event-popup-inn .event-popup-heading p {
        font-family: Lato;
        font-style: normal;
        font-weight: normal;
        font-size: 16px;
        line-height: 19px;
        color: #1E1F22;
        display: block;
        margin: 0 !important;
        padding: 0;
    }

    .event-popup .event-popup-inn .event-form {
        width: 100%;
        display: block;
        overflow: auto;
        max-height: 100%;
        padding-right: 10px;
    }

    .event-popup .event-popup-inn .event-form .form-row>* {
        font-family: 'Montserrat';
        font-style: normal;
        font-weight: 400;
        width: 100%;
        min-height: 40px;
        font-size: 14px;
        margin-bottom: 10px;
        background: #FFFFFF;
        border-radius: 4px;
    }

    .event-popup .event-popup-inn .event-form .form-row #calendar {
        width: 80%;
    }

    .event-popup .event-popup-inn .event-form .form-row textarea {
        padding: 5px 8px;
    }

    .event-popup .event-popup-inn .event-form .form-row p {
        min-height: 10px;
        margin-bottom: 0px;
        color: #000;
    }

    .event-popup .event-popup-inn .event-form .form-row .column-3 input[name="start"],
    .event-popup .event-popup-inn .event-form .form-row .column-3 input[name="end"],
    .event-popup .event-popup-inn .event-form .form-row .column-3 span {
        width: 40%;
        min-height: 40px;
        font-size: 14px;
        margin-bottom: 10px;
    }

    .event-popup .event-popup-inn .event-form .form-row input[type=text] {
        background: #FFFFFF !important;
        /*border: 1px solid #DCDEE0 !important;*/
        border-radius: 4px !important;
    }

    .event-popup .event-popup-inn .event-form .form-row .column-2 {
        display: flex;
    }

    .event-popup .event-popup-inn .event-form .form-row .column-2>* {
        min-height: 40px;
        font-size: 14px;
        margin-bottom: 10px;
        margin-right: 10px;
    }

    .event-popup .event-popup-inn .event-form .form-row .column-2 select.asset-type {
        width: 30%;
    }

    .event-popup .event-popup-inn .event-form .form-row .column-2 select.asset-name {
        width: 70%;
        margin-left: 20px;
    }

    .event-popup .event-popup-inn .event-form .form-row .column-2 .delete-asset svg {
        padding-top: 10px;
        width: 20px;
    }

    .event-popup .event-popup-inn .event-form .event-actions {
        text-align: right;
    }

    .event-popup .event-popup-inn .event-form .event-actions .cancel-button {
        background: #FFFFFF;
        border: 1px solid #78818B;
        border-radius: 6px;
        margin-right: 10px;
    }

    .event-popup .event-popup-inn .event-form .event-actions .create-button {
        background: linear-gradient(90deg, #F5286E 0%, #FC6D43 100%);
        border-radius: 8px;
        color: white;
    }

    .event-popup .event-popup-inn .event-form .form-row button {
        font-weight: 600;
        border-radius: 8px;
        width: 20%;
        background: linear-gradient(90deg, #F5286E 0%, #FC6D43 100%);
    }

    .event-popup .event-popup-inn .event-form .form-row button.send-notification-now {
        color: #78818B!important;
        border: 1px solid #78818B!important;
        background: #fff!important;
    }

    .event-popup .event-popup-inn .event-form .form-row .add-asset-button {
        border: 1px solid #DCDEE0;
        background: linear-gradient(90deg, #F5286E 0%, #FC6D43 88.61%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        text-fill-color: transparent;
        font-family: 'Montserrat';
        font-style: normal;
        font-weight: 600;
        font-size: 14px;
        line-height: 17px;
    }

    .event-popup .event-popup-inn .event-form .form-row .add-asset-button .plus-sign {
        font-size: 18px;
        vertical-align: bottom;
    }

    .event-popup .event-popup-inn .event-form .form-row span.select2-selection {
        min-height: 40px;
        display: flex;
        align-items: center;
        background: #FFFFFF;
        border: 1px solid #DCDEE0;
        border-radius: 4px;
    }

    .event-popup .event-popup-inn .event-form .form-row .select2-selection__arrow {
        top: auto;
    }

    .event-popup .event-popup-inn .event-form p {
        font-family: 'Lato';
        font-style: normal;
        font-weight: 400;
        font-size: 16px;
        line-height: 19px;
    }

    .event-popup-close-link {
        font-family: 'Montserrat';
        font-style: normal;
        font-weight: 700;
        font-size: 20px;
        line-height: 25px;
        background: linear-gradient(90deg, #F5286E 0%, #FC6D43 88.61%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        text-fill-color: transparent;
        cursor: pointer;
    }

    .event-popup h2 {
        font-family: 'Montserrat';
        font-style: normal;
        font-weight: 700;
        font-size: 20px;
        line-height: 24px;
    }

    .event-popup hr {
        border: 1px solid #E9ECEF;
    }

    .event-popup ul {
        list-style: none;
    }

    /* .event-popup ul li::before {
        content: "\2022";
        color: #78818B;
        font-weight: bold;
        display: inline-block; 
        width: 1em;
        margin-left: -1em;
    } */
    .event-popup li {
        font-family: 'Lato';
        font-style: normal;
        font-weight: 400;
        font-size: 16px;
        line-height: 19px;
        margin-bottom: 5px;
        color: #000000;
    }

    .event-popup li ul {
        margin-top: 15px;
    }

    .event-popup h3 {
        font-family: 'Montserrat';
        font-style: normal;
        font-weight: 700;
        font-size: 18px;
        line-height: 22px;
    }

    .event-popup .table {
        display: table;
        margin-top: 15px;
    }

    .event-popup .row {
        display: table-row;
    }

    .event-popup .cell {
        display: table-cell;
        padding-bottom: 5px;
        padding-right: 15px;
    }

    .event-popup .cell.bold {
        font-weight: 700;
    }

    .event-popup a {
        background: linear-gradient(90deg, #F5286E 0%, #FC6D43 88.61%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        text-emphasis-color: transparent;
        mix-blend-mode: normal;
    }

    .event-details-popup .start-datetime,
    .event-details-popup .end-datetime {
        display: inline-block;
    }

    .event-details-popup .end-datetime {
        margin-left: 70px;
    }

    .event-details-popup .section-title {
        font-family: 'Montserrat';
        font-style: normal;
        font-weight: 400;
        font-size: 10px;
        line-height: 12px;
        color: #79808A;
    }

    .event-details-popup p,
    .event-details-popup p {
        font-family: 'Lato';
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 17px;
        color: #1E1F22;
    }

    .event-details-popup .location {
        margin-top: 15px;
        margin-bottom: 15px;
    }

    .event-details-popup .event-body p b {
        font-family: 'Lato' !important;
        font-style: normal !important;
        font-weight: 700 !important;
        font-size: 14px !important;
        line-height: 17px !important;
    }

    .event-details-popup .event-body .emptyP {
        margin: 0px !important;
    }

    .event-details-popup .event-body .description- b {
        display: block !important;
        font-family: 'Montserrat' !important;
        font-style: normal !important;
        font-weight: 400 !important;
        font-size: 10px !important;
        line-height: 12px !important;
        color: #79808A !important;
        margin-top: 15px !important;
    }

    .event-details-popup .event-body ul.names li {
        font-family: 'Lato';
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 17px;
        color: #1E1F22;
    }

    .event-details-popup .event-actions {
        display: flex;
        justify-content: end;
        flex-direction: row-reverse;
        margin-top: 20px;
    }

    .event-details-popup .event-actions>* {
        width: 40%;
    }

    .event-details-popup .event-actions .delete-button {
        background: #FFFFFF;
        border: 1px solid #78818B;
        border-radius: 6px;
    }

    .event-details-popup .event-actions .edit-button {
        background: linear-gradient(90deg, #F5286E 0%, #FC6D43 100%);
        box-shadow: 0px 5px 15px rgba(245, 40, 110, 0.35);
        border-radius: 8px;
        color: white;
        margin-left: 12px;
    }

    /* Mobile CSS */
    @media only screen and (max-width: 600px) {
        .event-popup {
            width: 100vw;
            height: 100vh;
        }
    }

    /* <!-- Event Popup CSS End --> */

    /* <!-- jQuery Modal CSS --> */
    .jquery-modal.blocker {
        z-index: 999;
        background-color: rgba(0, 0, 0, 0.4);
    }

    .jquery-modal .modal {
        overflow: visible;
        max-width: 800px;
    }

    .jquery-modal p.inventory_info,
    .jquery-modal p.inventory_info a {
        font-family: 'Lato';
        font-style: normal;
        font-weight: 400;
        font-size: 16px;
        line-height: 19px;
        margin-bottom: 5px;
        color: #1d2327;
    }

    .jquery-modal p.inventory_info a {
        background: linear-gradient(90deg, #F5286E 0%, #FC6D43 88.61%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        text-emphasis-color: transparent;
        mix-blend-mode: normal;
    }

    .jquery-modal .section {
        padding: 0;
        margin-top: 10px;
        margin-bottom: 10px;
    }

    .jquery-modal .section h2 {
        font-weight: 700;
        margin-bottom: 5px;
    }

    .jquery-modal table {
        text-align: center;
        width: 100%;
    }

    .jquery-modal table th,
    .jquery-modal table td {
        border: 0.5px solid;
        padding: 5px;
    }

    /* <!-- jQuery Modal CSS End --> */

    /* Custom radio button style */
    .radio-container {
        /*display: inline-block;*/
        position: relative;
        padding-left: 30px;
        cursor: pointer;
        font-size: 16px;
        width: 7%!important;
    }

    .radio-container input {
        /*position: absolute;
        opacity: 0;*/
        cursor: pointer;
        vertical-align: middle;
        margin-right: 10px;
    }

    .radio-container input[type=radio]:checked::before {
        background: #000;
    }


    .checkmark {
        position: absolute;
        top: 0;
        left: 0;
        height: 20px;
        width: 20px;
        background-color: #eee;
    }

    .radio-container:hover input~.checkmark {
        background-color: #ccc;
    }

    .radio-container input:checked~.checkmark {
        background-color: #2196f3;
    }

    .checkmark:after {
        content: "";
        position: absolute;
        display: none;
    }

    .radio-container input:checked~.checkmark:after {
        display: block;
    }

    .radio-container .checkmark:after {
        left: 7px;
        top: 4px;
        width: 5px;
        height: 10px;
        border: solid white;
        border-width: 0 2px 2px 0;
        transform: rotate(45deg);
    }

    /* select2 */
    .select2-search__field {
        width: 100% !important;
    }

    .select2-container--default.select2-container--disabled .select2-selection--multiple {
        background-color: #fff;
    }





.mb-10{
    margin-bottom: 10px;
}

.unef-field-item-wrap {
        /*margin-left: -6px;
        margin-right: -6px;*/
        grid-row-gap: 10px;
        margin-bottom: 10px;
    }

    .unef-field-item-wrap.promo-code-item-row {
        position: relative;
        margin-bottom: 40px
    }

    .unef-field-item-wrap.promo-code-item-row.loading::before {
        width: 100%;
        height: 100%;
        content: '';
        position: absolute;
        left: 0;
        top: 0;
        right: 0;
        bottom: 0;
        display: block;
        z-index: 111;
        background-color: rgba(255, 255, 255, .4)
    }

    .unef-field-item-wrap.promo-code-item-row.loading:after {
        width: 100px;
        height: 100px;
        display: block;
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        content: '';
        z-index: 30000002;
        opacity: 1;
        visibility: visible;
        transition: all 0.05s ease-in-out 0s;
        background-image: url(/wp-content/themes/hello-theme-child-master/aws/img/dots.svg);
        background-repeat: no-repeat;
        background-position: 23px center;
        background-size: 100px auto
    }

    .unef-field-item-wrap:last-child {
        margin-bottom: 0
    }

    .unef-field-item-wrap.promo-code-item-row .unef-field-trash {
        position: absolute;
        right: 6px;
        top: -30px;
        display: block;
        box-shadow: none !important
    }

    .unef-field-item-wrap.promo-code-item-row .unef-field-trash svg {
        display: block;
        height: 20px;
        width: 20px
    }

    .unef-field-item-wrap .unef-field-item {
        width: 50%;
        /*padding-left: 6px;
        padding-right: 6px;*/
        position: relative;
        display: flex;
        flex-wrap: wrap;
        align-content: flex-start
    }

    .unef-field-item-wrap .unef-field-item.full {
        width: 100%
    }

    .unef-field-item-wrap .unef-field-item.full .unef-field-item.full {
        padding-left: 0;
        padding-right: 0
    }

    .unef-field-item-wrap .unef-field-item.pos-end {
        justify-content: flex-end
    }

    .unef-field-item-wrap .unef-field-item.hide-parking-info {
        display: none
    }

    .unef-field-item-wrap .unef-field-item h3,
    .unef-field-item-wrap .unef-field-item h3.multi-day-number {
        font-family: 'Montserrat';
        font-style: normal;
        font-weight: 600;
        font-size: 14px;
        line-height: 17px;
        color: #000;
        padding: 0;
        margin: 0;
        display: block
    }

    .multi-day-add-btn.disable {
        opacity: .3;
        pointer-events: none
    }

    #pricing-list-section .unef-field-item-wrap .unef-field-item h3 {
        padding-top: 14px;
        padding-bottom: 6px;
    }

    .unef-field-item-wrap .unef-field-item .pass-check-box,
    .unef-field-item-wrap .unef-field-item.apply-ticket-field {
        position: relative;
        align-items: center;
        align-content: center
    }

    .unef-field-item-wrap .unef-field-item.apply-ticket-field .info-ic,
    .unef-field-item-wrap .unef-field-item .pass-check-box .info-ic {
        margin-left: 6px;
        display: block;
        width: 17px;
        height: 17px;
        cursor: pointer;
        position: relative
    }

    .unef-field-item-wrap .unef-field-item.apply-ticket-field .info-ic svg,
    .unef-field-item-wrap .unef-field-item .pass-check-box .info-ic svg {
        display: block
    }

    .unef-field-item-wrap .unef-field-item.apply-ticket-field .info-ic .promo-info-pop {
        background: #FFF;
        box-shadow: 0 5px 20px rgba(11, 7, 110, .07);
        border-radius: 4px;
        width: 192px;
        padding: 14px;
        position: absolute;
        display: block;
        left: -20px;
        top: calc(100% + 5px);
        opacity: 0;
        visibility: hidden;
        transition: all 0.35s ease-in-out 0s
    }

    .unef-field-item-wrap .unef-field-item.apply-ticket-field .info-ic:hover .promo-info-pop {
        opacity: 1;
        visibility: visible
    }

    .unef-field-item-wrap .unef-field-item.apply-ticket-field .info-ic .promo-info-pop p {
        font-family: 'Lato';
        font-style: normal;
        font-weight: 500;
        font-size: 13px;
        line-height: 17px;
        letter-spacing: .08px;
        color: #1E1F22
    }

    .unef-field-item-wrap .unef-field-item .pass-check-box+.pass-check-box,
    .unef-field-item-wrap .unef-field-item .multi-check-box+.multi-check-box {
        margin-left: 24px
    }

    .unef-field-item-wrap .unef-field-item .unef-field-admission-details {
        border: 1px solid #DCDEE0;
        border-radius: 4px;
        width: 100%;
        justify-content: space-between;
        padding: 22px 40px
    }

    .unef-field-item-wrap .unef-field-item .unef-field-admission-details label {
        font-family: 'Lato';
        font-style: normal;
        font-weight: 500;
        font-size: 10.0546px;
        line-height: 12px;
        color: #79808A;
        display: block;
        margin-bottom: 6px
    }

    .unef-field-item-wrap .unef-field-item .unef-field-admission-details p {
        font-family: 'Lato';
        font-style: normal;
        font-weight: 400;
        font-size: 14.0764px;
        line-height: 17px;
        color: #000
    }

    .unef-field-item-wrap .unef-field-item .unef-field-trash {
        position: absolute;
        right: 6px;
        top: 0;
        display: block;
        box-shadow: none !important
    }

    .unef-field-item-wrap .unef-field-item .unef-field-trash svg {
        display: block
    }

    .unef-field-item-wrap .unef-field-item .unef-file-uploader+.unef-field-trash {
        top: auto;
        bottom: 0
    }

    .unef-field-item-wrap .unef-field-item label.unef-field-label {
        font-family: 'Montserrat';
        font-style: normal;
        font-weight: 400;
        font-size: 10px;
        line-height: 12px;
        color: #79808A;
        display: flex;
        flex-wrap: wrap;
        padding-left: 12px;
        position: absolute;
        left: 6px;
        top: 10px
    }

    .unef-field-item-wrap .unef-field-item label.unef-field-label span.req {
        font-weight: 500;
        font-size: 12px;
        line-height: 12px;
        color: #FE0200;
        display: block;
        margin-left: 4px
    }

    .unef-field-item-wrap .unef-field-item .unef-field-container {
        display: block;
        width: 100%;
        position: relative
    }

    .unef-field-item-wrap .unef-field-item .unef-field-container.url-fld {
        position: relative
    }

    .unef-field-item-wrap .unef-field-item .unef-field-container.url-fld::before {
        content: "https://";
        position: absolute;
        left: 19px;
        top: 1px;
        padding-top: 22px;
        padding-bottom: 9px;
        font-family: 'Lato';
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 17px;
        color: #1E1F22;
        display: block;
        z-index: 1
    }

    .unef-field-item-wrap .unef-field-item .unef-field-container .optional-check-field-wrap {
        position: absolute;
        width: 132px;
        right: 1px;
        top: 1px;
        bottom: 1px;
        border-left: 1px solid #DCDEE0;
        display: flex;
        flex-wrap: wrap;
        justify-content: flex-start;
        align-items: center;
        align-content: center;
        background-color: #fff;
        border-radius: 0 4px 4px 0;
        padding: 0 24px
    }

    .unef-field-item-wrap .unef-field-item .character-limit {
        font-family: 'Montserrat';
        font-style: normal;
        font-weight: 400;
        font-size: 10px;
        line-height: 12px;
        color: #79808A;
        position: absolute;
        top: 10px;
        right: 6px;
        padding-right: 18px;
        display: block
    }

    .unef-field-item-wrap .unef-field-item .character-limit span {
        font-family: 'Montserrat';
        font-style: normal;
        font-weight: 400;
        font-size: 10px;
        line-height: 12px;
        color: #79808A
    }

    .unef-field-item-wrap .unef-field-item .unef-field-container input[type="text"],
    .unef-field-item-wrap .unef-field-item .unef-field-container input[type="email"],
    .unef-field-item-wrap .unef-field-item .unef-field-container input[type="number"],
    .unef-field-item-wrap .unef-field-item .unef-field-container input[type="tel"],
    .unef-field-item-wrap .unef-field-item .unef-field-container input[type="url"] {
        width: 100%;
        height: 44px;
        display: block;
        background: transparent;
        border: 1.00546px solid #DCDEE0;
        outline: 0 !important;
        box-shadow: none !important;
        border-radius: 4px !important;
        padding-left: 18px;
        padding-right: 18px;
        padding-top: 22px;
        padding-bottom: 9px;
        font-family: 'Lato';
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 17px;
        color: #1E1F22;
        position: relative;
        margin: 0
    }

    .unef-field-item-wrap .unef-field-item .unef-field-container.url-fld input[type="text"],
    .unef-field-item-wrap .unef-field-item .unef-field-container.url-fld input[type="url"] {
        padding-left: 64px
    }

    .unef-field-item-wrap .unef-field-item .unef-field-container textarea {
        width: 100%;
        min-height: 104px;
        display: block;
        background: transparent;
        border: 1.00546px solid #DCDEE0 !important;
        outline: 0 !important;
        box-shadow: none !important;
        border-radius: 4px !important;
        padding-left: 18px;
        padding-right: 18px;
        padding-top: 22px;
        padding-bottom: 9px;
        font-family: 'Lato';
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 17px;
        color: #1E1F22;
        position: relative;
        resize: none
    }

    .unef-field-item-wrap .unef-field-item .unef-field-container input.error,
    .unef-field-item-wrap .unef-field-item .unef-field-container textarea.error {
        border: 1.00546px solid #FE0200 !important
    }

    .unef-field-item-wrap .unef-field-item .unef-field-container .choose-promo-amount-option {
        width: 143px;
        position: absolute;
        right: 7px;
        top: 1px;
        bottom: 1px;
        border-radius: 0 4px 4px 0;
        background: #f8f8f9;
        z-index: 1
    }

    .unef-field-item-wrap .unef-field-item .unef-field-container .choose-promo-amount-option .select2-container span.select2-selection.select2-selection--single {
        border-radius: 0 4px 4px 0px !important;
        border: 1px solid transparent !important;
        padding-top: 15px
    }

    .unef-field-item-wrap .unef-field-item .error-msg {
        font-family: 'Lato';
        font-style: normal;
        font-weight: 400;
        font-size: 12px;
        line-height: 14px;
        color: red;
        padding-top: 4px;
        display: none
    }

    #ui-datepicker-div.ui-widget.ui-widget-content {
        padding: 20px 10px;
        background: #FFF;
        border: .943114px solid #DCDEE0;
        box-shadow: 0 1.88623px 27.5012px rgba(0, 0, 0, .1);
        border-radius: 9.43114px;
        width: 332px;
        margin: 4px 0
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-header {
        background-color: transparent;
        padding: 0;
        border: 0;
        border-radius: 0;
        margin-bottom: 16px
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-header .ui-datepicker-title {
        font-family: 'Lato';
        font-style: normal;
        font-weight: 700;
        font-size: 17.4194px;
        line-height: 20px;
        letter-spacing: -.132036px;
        color: #000;
        margin: 0 20px
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-header .ui-corner-all {
        width: 20px;
        height: 20px;
        background-color: transparent;
        border: 0;
        top: 0;
        cursor: pointer
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-header .ui-corner-all.ui-state-hover {
        background: none
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-header .ui-corner-all.ui-datepicker-prev {
        left: 0
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-header .ui-corner-all.ui-datepicker-next {
        right: 0
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-header .ui-corner-all .ui-icon {
        width: 20px;
        height: 20px;
        display: block;
        top: 0;
        left: 0;
        margin-left: 0;
        margin-top: 0;
        background-color: transparent
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-header .ui-corner-all.ui-datepicker-prev .ui-icon {
        background-image: url(../img/calendar-next-ic.svg);
        background-repeat: no-repeat;
        background-position: center center;
        -webkit-transform: scaleX(-1);
        transform: scaleX(-1)
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-header .ui-corner-all.ui-datepicker-next .ui-icon {
        background-image: url(../img/calendar-next-ic.svg);
        background-repeat: no-repeat;
        background-position: center center
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-calendar thead tr {
        display: flex;
        flex-wrap: wrap;
        width: 100%
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-calendar thead tr th {
        width: 40px;
        font-family: 'Lato';
        font-style: normal;
        font-weight: 400;
        font-size: 11.3174px;
        line-height: 19px;
        letter-spacing: -.132036px;
        color: #969DA5;
        text-transform: capitalize
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-calendar thead tr th+th {
        margin-left: 5px
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-calendar tbody tr {
        display: flex;
        flex-wrap: wrap;
        width: 100%;
        margin-top: 12px
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-calendar tbody tr td {
        padding: 1px;
        width: 40px;
        height: 40px;
        border-radius: 100%
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-calendar tbody tr td+td {
        margin-left: 5px
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-calendar tbody tr td .ui-state-default {
        width: 100%;
        height: 38px;
        font-family: 'Lato';
        font-style: normal;
        font-weight: 600;
        font-size: 13.2036px;
        line-height: 20px;
        color: #1E1F22;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        align-content: center;
        justify-content: center;
        border: 0;
        outline: 0 !important;
        box-shadow: none;
        padding: 0;
        background: none;
        border-radius: 100%
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-calendar tbody tr td:hover {
        background: #F8F8F8
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-calendar tbody tr td.ui-datepicker-today {
        background: linear-gradient(90deg, #F5286E 0%, #FC6D43 88.61%);
        padding: 1px
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-calendar tbody tr td.ui-datepicker-today .ui-state-default {
        background-color: #fff
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-calendar tbody tr td.ui-datepicker-current-day {
        background: linear-gradient(90deg, #F5286E 0%, #FC6D43 88.61%)
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-calendar tbody tr td.ui-datepicker-current-day a.ui-state-default {
        color: #fff
    }

    #ui-datepicker-div.ui-datepicker .ui-datepicker-calendar tbody tr td.ui-datepicker-today.ui-datepicker-current-day a.ui-state-default {
        color: #1E1F22
    }

    .ui-timepicker-container {
        position: absolute;
        overflow: hidden;
        box-sizing: border-box;
        z-index: 125 !important;
    }

    .ui-timepicker-container {
        background: #FFF;
        border: .649701px solid #DCDEE0;
        box-shadow: 0 1.2994px 18.9453px rgba(0, 0, 0, .1);
        border-radius: 6.49701px;
        padding: 0;
        margin: 4px 0
    }

    .ui-timepicker-container .ui-widget.ui-widget-content {
        padding: 0
    }

    .ui-timepicker-container .ui-widget.ui-widget-content .ui-timepicker-viewport li.ui-menu-item a {
        padding: 15px 25px;
        font-family: 'Lato';
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 13px;
        letter-spacing: -.0909581px;
        color: #1E1F22;
        display: block;
        border: 0;
        border-radius: 0
    }

    .ui-timepicker-container .ui-widget.ui-widget-content .ui-timepicker-viewport li.ui-menu-item a.ui-state-hover {
        background: #F3F3F3;
        border-radius: 0;
        border: 0
    }

    .ui-timepicker-viewport {
        box-sizing: content-box;
        display: block;
        height: 205px;
        margin: 0;
        padding: 0;
        overflow: auto;
        overflow-x: hidden
    }


.d-flex {
        display: flex;
    }

.mySelect {
        height: 50px;
        display: block;
        background: transparent;
        border: 1.00546px solid #d3d0d0 !important;
        outline: 0 !important;
        box-shadow: none !important;
        border-radius: 4px !important;
        padding-left: 18px;
        padding-right: 18px;
        padding-top: 10px;
        padding-bottom: 22px;
        font-family: 'Lato';
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 17px;
        color: #1E1F22;
        position: relative;
    }
    

    .selectedOptions ul li {
        margin: 10px 0px;
        padding: 12px;
        border: 1px solid #d3d0d0;
        border-radius: 5px;
    }

    .select2{
        width: 100% !important;
        border: 1.00546px solid #DCDEE0 !important;
        border-radius: 4px;
        padding: 5px;
    }

   

    .unef-field-item-wrap .unef-field-item .unef-field-container .choose-promo-amount-option .select2-container span.select2-selection.select2-selection--single {
        border-radius: 0 4px 4px 0px !important;
        border: 1px solid transparent !important;
        padding-top: 15px
    }

    .unef-field-item-wrap .unef-field-item .unef-field-container .select2-container {
        width: 100% !important
    }

    .unef-field-item-wrap .unef-field-item .unef-field-container select.readonly+.select2-container {
        pointer-events: none
    }

    .unef-field-item-wrap .unef-field-item .unef-field-container .select2-container span.select2-selection.select2-selection--single {
        width: 100%;
        height: 50px;
        display: block;
        background: transparent;
        outline: 0 !important;
        box-shadow: none !important;
        border-radius: 4px !important;
        padding-left: 18px;
        padding-right: 18px;
        padding-top: 22px;
        padding-bottom: 9px;
        font-family: 'Lato';
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 17px;
        color: #1E1F22;
        position: relative
    }

    .unef-field-item-wrap .unef-field-item .unef-field-container select.error+.select2-container span.select2-selection.select2-selection--single {
        border: 1.00546px solid #FE0200 !important
    }

    .select2-container--default .select2-selection--single .select2-selection__rendered {
        /*padding-left: 34px;*/
        font-size: 14px;
        color: #ccc;
    }
    span.select2-selection.select2-selection--multiple {
        border: none !important;
        height: 32px;
    }

    .unef-field-item-wrap .unef-field-item .unef-field-container .select2-container span.select2-selection.select2-selection--single .select2-selection__rendered {
        font-family: 'Lato';
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
        line-height: 17px;
        color: #1E1F22;
        padding: 0
    }

    .unef-field-item-wrap .unef-field-item .unef-field-container .select2-container--default .select2-selection--single .select2-selection__arrow {
        width: 13px;
        height: 100%;
        right: 22px;
        top: 0;
        background-image: url('https://assets-qa.unation.com/wp-content/plugins/unation-guides/img/dropdown-arrow.svg');
        background-repeat: no-repeat;
        background-position: center center
    }

    .unef-field-item-wrap .unef-field-item .unef-field-container .select2-container--default .select2-selection--single .select2-selection__arrow b {
        display: none;
    }

    .unef-field-item-wrap .unef-field-item .unef-field-container .select2-container--default.select2-container--open .select2-selection--single .select2-selection__arrow {
        transform: rotate(180deg);
    }

    .select2-container.select2-container--default .select2-dropdown {
        margin-top: 0;
        border: 0;
        background: #FFF;
        box-shadow: 0 4px 4px rgba(0, 0, 0, .25);
        border-radius: 0 0 5px 5px;
        min-width: 143px
    }

    .select2-container.select2-container--default .select2-dropdown .select2-search--dropdown {
        display: none;
    }

    .select2-container.select2-container--default .select2-dropdown .select2-results {
        padding: 0;
    }

    .select2-container.select2-container--default .select2-dropdown .select2-results .select2-results__options {
        max-height: 310px;
    }

    .select2-container.select2-container--default .select2-dropdown .select2-results .select2-results__options li.select2-results__option {
        padding: 13px 18px;
        font-family: 'Lato';
        font-style: normal;
        font-weight: 400;
        font-size: 14.0764px;
        line-height: 17px;
        color: #000;
    }

    .select2-container.select2-container--default .select2-dropdown .select2-results .select2-results__options li.select2-results__option[data-selected="true"] {
        background-color: rgba(217, 217, 217, .1)
    }

    .select2-container.select2-container--default .select2-dropdown .select2-results .select2-results__options li.select2-results__message {
        display: none !important
    }
    .unef-field-container .select2-container span.select2-selection.select2-selection--single {
        text-align: left
    }

    .select2-container--default .select2-selection--single .select2-selection__rendered.req {
        color: #FE0200
    }

    .attendee-info-field-item .select2-container {
        width: 84px !important
    }

    .attendee-info-field-item .select2-container .select2-selection--single .select2-selection__rendered {
        padding-right: 30px
    }

    select,
    span.select2-selection.select2-selection--single {
        box-shadow: none !important;
        background: none !important;
        border: 0 !important;
        font-family: 'Montserrat';
        font-style: normal;
        font-weight: 600;
        font-size: 10px;
        line-height: 28px;
        color: #78818B
    }

    .select2-container--default.select2-container--open .select2-selection--single .select2-selection__arrow b {
        border: 0
    }

    .select2-container--default .select2-selection--single .select2-selection__arrow {
        
        background-image: url('https://assets-qa.unation.com/wp-content/plugins/unation-guides/img/dropdown-arrow.svg');
        background-repeat: no-repeat;
        background-position: center center;
        background-size: 12px auto;
        width: 14px;
        height: 8px;
        transition: all 0.35s ease-in-out 0s;
        top: 14px;
        right: 10px
    }

    .select2-container--default .select2-selection--single .select2-selection__arrow b {
        border: 0;
        display: none
    }

    .select2-container--default.select2-container--open .select2-selection--single .select2-selection__arrow {
        transform: rotate(180deg)
    }

    .select2-container--default .select2-search--inline .select2-search__field{
        border: none!important;
        margin: unset;
        padding-top: 0px!important;
        padding-bottom: : 0px!important;
    }

    .select2-container--default .select2-selection--multiple .select2-selection__rendered li.select2-selection__choice{
        
        display: none!important;
    }

    .select2-container--default .select2-selection--multiple .select2-selection__rendered li{
        margin: unset;
        padding-left: 40px;
    }

    .all-selected .flex-item-1{
        width: 80%;
    }

    .all-selected .flex-item-2{
        width: 20%;
    }
    .all-selected .flex-item-2 .select2,
    .metro-selected .flex-item-2 .select2,
    .users-selected .content-type-item .flex-item-2 .select2
     {
        height: 44px;
        border-radius: 0px 4px 4px 0px;
        background: #DCDEE033;
    }
    .all-selected .flex-item-2 .select2 span.select2-selection.select2-selection--single,
    .metro-selected .flex-item-2 .select2 span.select2-selection.select2-selection--single,
    .users-selected .content-type-item .select2 span.select2-selection.select2-selection--single
    {
        
            font-family: 'Lato';
            font-style: normal;
            font-weight: 500;
            font-size: 14px;
        }

    .all-selected .flex-item-2 .select2-container--default .select2-selection--single .select2-selection__rendered,
    .metro-selected .flex-item-2 .select2-container--default .select2-selection--single .select2-selection__rendered,
    .users-selected .content-type-item .flex-item-2 .select2-container--default .select2-selection--single .select2-selection__rendered
    {
        
            color: #000;
            font-family: 'Lato';
            font-style: normal;
            font-weight: 500;
            font-size: 14px;
        }

    .all-selected .flex-item-2 .select2-container--default .select2-selection--single .select2-selection__arrow,
    .metro-selected .flex-item-2 .select2-container--default .select2-selection--single .select2-selection__arrow,
    .users-selected .content-type-item .flex-item-2 .select2-container--default .select2-selection--single .select2-selection__arrow,
    {
        width: 13px;
        height: 100%;
        right: 22px;
        top: 0;
        background-image: url('https://assets-qa.unation.com/wp-content/plugins/unation-guides/img/dropdown-arrow.svg');
        background-repeat: no-repeat;
        background-position: center center;
        background-color: unset;
    }
    .selectedOptions{
        width: 100%;
    }

    .all-selected .flex-item-2 .unef-field-item-wrap .unef-field-item.full,
    .metro-selected .flex-item-2 .unef-field-item-wrap .unef-field-item.full,
    .users-selected .content-type-item .flex-item-2 .unef-field-item-wrap .unef-field-item.full
    {
        padding: 0px;
    }

    .metro-selected .content-type-item{
        width: 50%;
    }

    .users-selected .content-type-item{
        width: 50%;
    }

     .content-type-item .flex-item-1{
        width: 70%;
    }
     .content-type-item .flex-item-2{
        width: 30%;
    }

    .metro-item .unef-field-label{
        top: 6px!important;
    }

    .metro-item .select2{
        height: 44px!important;
    }
    .metro-item .select2-container span.select2-selection.select2-selection--single{
       height: 44px!important;
       padding-top: 14px!important;
    }

    .metro-item .unef-field-item .unef-field-container .select2-container--default .select2-selection--single .select2-selection__arrow{
       background-color: unset!important;
       background-image: url('https://assets-qa.unation.com/wp-content/plugins/unation-guides/img/dropdown-arrow.svg')!important;
    }

    .un-content-type-field .select2{
        height: 44px!important;
    }

    .users-item .unef-field-label{
        z-index: 99999;
        top: 4px!important;
    }


.mt-45{
    margin-top: 45px;
}





</style>